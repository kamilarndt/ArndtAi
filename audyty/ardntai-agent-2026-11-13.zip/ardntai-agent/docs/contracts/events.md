# Kontrakt eventów — v1 (zamrożony 2026-11-13)

Źródło prawdy: `app/src/context.rs` (`Session::event`) i `app/src/agent.rs`.
Każdy event to jedna linia JSONL w `.agent/sessions/<session_id>.jsonl`:

```json
{"at": 1794534331, "kind": "tool_call", "data": {"step": 1, "tool": "fs.write", "args": {"path": "a.txt", "content": "x"}}}
```

- `at` — uniksowy czas w sekundach (u64),
- `kind` — jeden z typów poniżej,
- `data` — obiekt; pola wymagane są wyszczególnione.

Konsument (frontend Fazy C) czyta wyłącznie ten format. Dodanie typu = nowa
wersja tego pliku, nie cicha zmiana.

## Typy eventów

| `kind` | Kiedy | `data` |
|---|---|---|
| `task` | start sesji | `text` — zadanie |
| `thought` | model zwrócił decyzję | `step`, `thought` |
| `tool_call` | przed wykonaniem narzędzia | `step`, `tool`, `args` |
| `tool_result` | po wykonaniu | `step`, `tool`, `ok`, `code`, `bytes`, `output` |
| `tool_result_cached` | krok `done` odczytany z SQLite (wznowienie) | `step`, `tool`, `result` |
| `tool_result_skipped` | krok `proposed` po crashu — at-most-once | `step`, `tool`, `reason` |
| `denied` | bramka allowlisty/budżetu odrzuciła akcję | `step`, `tool`, `reason`, `drift` |
| `store` | stan magazynu na starcie | `path`, `journal_mode`, `busy_timeout` |
| `store_error` | błąd SQLite (nie zabija pętli) | `stage`, `message` |
| `error` | zakończenie z błędem | `message` |
| `summary` | zawsze na końcu | `status`, `steps`, `tool_calls`, `denied`, `drift`, `reason` |

`status` w `summary`: `DONE`, `FAILED_BUDGET`, `FAILED_STALLED`, `FAILED_ERROR`,
`FAILED_STEPS`.

## Stan trwały (SQLite `.agent/state.db`)

Eventy to log; stan odtwarzalny jest w tabelach. Kontrakt między nimi:

| tabela | kolumny | rola |
|---|---|---|
| `sessions` | `id`, `task`, `started_at` | jedna sesja = jeden plik JSONL |
| `steps` | `session_id`, `step_id`, `tool`, `args_json`, `status`, `result_json` | `status` ∈ `proposed`/`done`/`abandoned`; klucz `(session_id, step_id)` |
| `outbox` | `session_id`, `step_id`, `payload`, `created_at` | unikalny per krok (`outbox_step_once`) |

Reguły:

1. `proposed` przed efektem ubocznym, `done` + `result_json` po nim — jedna transakcja z outboxem, gdy narzędziem jest `notify.send`.
2. Wznowienie: `done` → wynik z `result_json`, zero wykonania. `proposed` → `abandoned`, zero wykonania (at-most-once).
3. Jeden proces pisze (`PRAGMA journal_mode=WAL`, `busy_timeout=5000`); serwer MCP czyta i dopisuje własne kroki, ale nigdy nie dotyka cudzych wierszy.

## Odstępstwa od `09-INSTRUKCJA-DOKONCZENIA.md:40-42`

Dokument wymienia tabele `tasks`, `sessions`, `transcripts`, `outbox`.
Stan faktyczny: `sessions`, `steps`, `outbox`. `transcripts` są plikami JSONL
(eventy powyżej), a `tasks` nie istnieje — zadanie jest kolumną w `sessions`.
Powód: krok jest jednostką idempotencji, transkrypt jest logiem; duplikowanie
go w tabeli dawało dwa źródła prawdy. Świadome odstępstwo, nie przeoczenie.
