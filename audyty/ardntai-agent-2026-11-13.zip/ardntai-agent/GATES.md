# Gates: ArndtAi — domknięcie M0/Fazy B zgodnie z audytem 2026-11-13

OWNS: app/src/**, app/Cargo.toml, docs/**, README.md, scripts/**, GATES.md

Scope: naprawa S1/S2 z `audyty/arndtai-2026-11-13.md` (F1-F8, F16, F20-F22, F12) i doprowadzenie projektu do `ready` w Craft Anything z realnymi dowodami.

- [x] G1: katalog `.agent` jest niedostępny przez symlink/alias (F1, F7)
  CHECK: cargo test --quiet tools::tests
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=bebc46b979e5d6380629e8d4f0934fff2260eda8f3f27b01d89e298860bcd821; exit=0; EXPECT=matched; output-sha256=532d3e37b41f0d8c7ccf4d1f42a18d3f183528b0bf0d9defb65eb5050d4b12fc; output-bytes=118; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G2: kroki są zapisywane i wznawiane bez powtórzenia efektu (F2, F8)
  CHECK: cargo test --quiet agent::tests
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=10e696243d702bde85398127268d9498cf3cfb76eb1cbacc3cc8d0fada10272e; exit=0; EXPECT=matched; output-sha256=14b9502d0f583f1ae4c9e323f196953cbe7e9deeb36828b5e0e82f370995415a; output-bytes=118; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G3: SQLite w trybie WAL z busy_timeout (F6)
  CHECK: cargo test --quiet store::tests::wal_and_busy_timeout
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=b529de5beaf4e4287691db2c5048b348d8f62ce5e0c17659a7c956e87ae07faf; exit=0; EXPECT=matched; output-sha256=e85c3ac850825ccf2b1f6815f1e020f8f9b0fdd2335af044c476e7192b9b4905; output-bytes=114; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G4: outbox jest transakcyjny i unikalny per krok (F4, F24)
  CHECK: cargo test --quiet store::tests::outbox_is_once_per_step
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=49ac8cca94e016a867dc540040322b5f03ea225b29dc2a3cf7483dce3bf7c04e; exit=0; EXPECT=matched; output-sha256=2c4b0b23315c3642ee70be9c726c4b503c95402068227b330b2462af258340b0; output-bytes=114; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G5: klucz API nie trafia do argv procesu curl (F5)
  CHECK: cargo test --quiet provider::tests
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=241bfe5486e928b01d03d7bb74f5ce4717089ace2aa18ad0b9b4bf753123c0cb; exit=0; EXPECT=matched; output-sha256=532d3e37b41f0d8c7ccf4d1f42a18d3f183528b0bf0d9defb65eb5050d4b12fc; output-bytes=118; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G6: powtórzony `step_id` w MCP nie wykonuje efektu drugi raz (F3)
  CHECK: cargo test --quiet mcp::tests
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=6cbaaf3490f3b648c052821344b3c75087eb3a354b8ca2f6cc32f8c7983acbd0; exit=0; EXPECT=matched; output-sha256=a2674e75de044a2d65e9c61974e72e2b8b1c1d371429e1f6521ceae31759391c; output-bytes=116; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G7: pełny zestaw testów projektu przechodzi
  CHECK: cargo test 2>&1 | tail -5
  EXPECT: test result: ok.
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=0e31f5f35aca98133ea5cc3c6fb57a38091557a75dbb0c9e2da4b4765838000c; exit=0; EXPECT=matched; output-sha256=14da33ef38e90db57a3513e3ef08c3c3a1b72d30a078c3d6390a93e9210a32a8; output-bytes=242; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G8: demo przechodzi 39/39 sprawdzeń
  CHECK: cargo run --quiet -- demo
  EXPECT: DEMO OK
  CWD: app
  EVIDENCE: automatic-evidence=v1; definition-sha256=409b2f4ab5160e1d865ca550d91bba940f3e85ab15b5c974d04c1d69a3efe3c4; exit=0; EXPECT=matched; output-sha256=ef5953af2470ae286228fd77ae054c7aba7953473e90b8158e313d7290176cfd; output-bytes=1558; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi/app; path=06cc7ff529f1/32 entries

- [x] G9: dowody są trwałe i spójne z `craft.json`, bez duplikatów `at_ms` (F12)
  CHECK: python3 scripts/verify.py --assert
  EXPECT: CHECKS OK
  CWD: .
  EVIDENCE: automatic-evidence=v1; definition-sha256=38b1d3dd34ab3c22afbfeb4965337d1e560357f56dbf0d29646bdd4b3beec2d8; exit=0; EXPECT=matched; output-sha256=86bbac4c12344c687d8f5fff3552aae5b4b152b2a34162ba180a2dbd52392533; output-bytes=10; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi; path=1a8468950027/40 entries

- [x] G10: deliverables Fazy B istnieją (F16, F28, F15)
  CHECK: test -f docs/contracts/events.md && test -f README.md && test -f docs/re/README.md && echo DELIVERABLES OK
  EXPECT: DELIVERABLES OK
  CWD: .
  EVIDENCE: automatic-evidence=v1; definition-sha256=2e78dcec970101bc31a8e9f776d68bfc0fc421cd93469e9d22c249ed29867126; exit=0; EXPECT=matched; output-sha256=cbf68df2f1f1c85cf96ed654bcdfac306cb070f779270610b4c9de9ec7dc9eee; output-bytes=16; shell=/bin/sh; cwd=/home/karndt/projects/ArndtAi; path=06cc7ff529f1/32 entries

- [x] G11: projekt w Craft Anything pokazuje `Ready` z realnymi checkami
  EVIDENCE: zrzut a11y (orca computer) — „ArndtAi, Ready", Study/Build/Check/Ready: Done, lista Check 1-5 z `cargo ... -> exit 0`; brak banera błędu po usunięciu starego `feed.json`
