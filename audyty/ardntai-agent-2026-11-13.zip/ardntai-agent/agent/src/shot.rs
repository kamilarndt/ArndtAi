//! `--screenshot <plik.png>` — zrzut okna do PNG.
//!
//! ArndtAi jest programem konsolowym: nie otwiera okna systemowego, wiec
//! „okno" jest rysowane bezpośrednio do bufora pikseli (120 klatek) i zapisane
//! jako PNG. Tryb jest bezobsługowy: nie zabiera fokusu, nic nie otwiera
//! i kończy się od razu po zapisaniu pliku. Bez tej flagi program działa
//! dokładnie tak jak wcześniej.
//!
//! Koder PNG jest minimalny (kolor 8-bit RGB, filtr 0, niezwarte bloki
//! deflate), żeby nie dokładać zależności do projektu.

use std::fs;
use std::io;
use std::path::Path;

const W: usize = 960;
const H: usize = 560;
const FRAMES: usize = 120;

pub fn save(path: &str) -> i32 {
    let mut canvas = Canvas::new(W, H);
    for frame in 0..FRAMES {
        draw(&mut canvas, frame);
    }
    match canvas.write_png(Path::new(path)) {
        Ok(()) => {
            println!("zapisano zrzut: {}", path);
            0
        }
        Err(e) => {
            eprintln!("nie mozna zapisac zrzutu {}: {}", path, e);
            2
        }
    }
}

struct Canvas {
    w: usize,
    h: usize,
    px: Vec<u8>,
}

impl Canvas {
    fn new(w: usize, h: usize) -> Canvas {
        Canvas {
            w,
            h,
            px: vec![0; w * h * 3],
        }
    }

    fn pixel(&mut self, x: usize, y: usize, c: [u8; 3]) {
        if x >= self.w || y >= self.h {
            return;
        }
        let i = (y * self.w + x) * 3;
        self.px[i] = c[0];
        self.px[i + 1] = c[1];
        self.px[i + 2] = c[2];
    }

    fn rect(&mut self, x: usize, y: usize, w: usize, h: usize, c: [u8; 3]) {
        for yy in y..(y + h).min(self.h) {
            for xx in x..(x + w).min(self.w) {
                self.pixel(xx, yy, c);
            }
        }
    }

    /// Pionowy gradient — tło „okna".
    fn gradient(&mut self, x: usize, y: usize, w: usize, h: usize, top: [u8; 3], bottom: [u8; 3]) {
        for yy in y..(y + h).min(self.h) {
            let t = if h <= 1 {
                0.0
            } else {
                (yy - y) as f32 / (h - 1) as f32
            };
            let c = [
                lerp(top[0], bottom[0], t),
                lerp(top[1], bottom[1], t),
                lerp(top[2], bottom[2], t),
            ];
            for xx in x..(x + w).min(self.w) {
                self.pixel(xx, yy, c);
            }
        }
    }

    fn write_png(&self, path: &Path) -> io::Result<()> {
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                fs::create_dir_all(parent)?;
            }
        }

        // Surowe skanline: filtr 0 + RGB.
        let mut raw = Vec::with_capacity((self.w * 3 + 1) * self.h);
        for y in 0..self.h {
            raw.push(0u8);
            raw.extend_from_slice(&self.px[y * self.w * 3..(y + 1) * self.w * 3]);
        }

        let mut out = Vec::new();
        out.extend_from_slice(&[0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a]);

        let mut ihdr = Vec::new();
        ihdr.extend_from_slice(&(self.w as u32).to_be_bytes());
        ihdr.extend_from_slice(&(self.h as u32).to_be_bytes());
        ihdr.extend_from_slice(&[8, 2, 0, 0, 0]); // 8 bitow, RGB, brak przeplotu
        write_chunk(&mut out, b"IHDR", &ihdr);
        write_chunk(&mut out, b"IDAT", &zlib_stored(&raw));
        write_chunk(&mut out, b"IEND", &[]);

        fs::write(path, out)
    }
}

fn lerp(a: u8, b: u8, t: f32) -> u8 {
    (a as f32 + (b as f32 - a as f32) * t).round().clamp(0.0, 255.0) as u8
}

/// Prosty generator szerokości „linii tekstu" — stały dla danego ziarna.
fn width_at(seed: u32, min: usize, max: usize) -> usize {
    let mut x = seed.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
    x ^= x >> 13;
    min + (x as usize % (max - min + 1))
}

fn draw(c: &mut Canvas, frame: usize) {
    // Tlo i pasek tytulu.
    c.gradient(0, 0, W, H, [16, 20, 27], [24, 30, 40]);
    c.rect(0, 0, W, 38, [30, 37, 48]);
    for (i, color) in [[244, 96, 96], [240, 190, 90], [96, 200, 128]].iter().enumerate() {
        let x = 18 + i * 18;
        c.rect(x, 16, 6, 6, *color);
    }
    c.rect(140, 16, 90, 6, [66, 76, 92]);

    // Panel boczny: lista krokow sesji.
    c.rect(0, 38, 224, H - 38, [20, 25, 34]);
    c.rect(20, 58, 70, 7, [70, 80, 96]);
    for i in 0..8usize {
        let y = 86 + i * 30;
        let active = i == 0;
        let bar = if active { [72, 168, 120] } else { [52, 60, 74] };
        let dot = if active { [96, 220, 160] } else { [80, 92, 110] };
        c.rect(20, y, 6, 6, dot);
        c.rect(36, y, width_at(i as u32 + 1, 80, 160), 6, bar);
    }
    c.rect(20, H - 46, 120, 5, [46, 54, 68]);

    // Naglowek glowny.
    c.rect(248, 62, 430, 13, [206, 214, 226]);
    c.rect(248, 86, 268, 7, [96, 106, 124]);

    // „Log" petli agenta: linie o roznej dlugosci.
    for i in 0..13usize {
        let y = 124 + i * 24;
        if y + 8 > H - 70 {
            break;
        }
        let color = if i % 4 == 2 {
            [84, 176, 128]
        } else {
            [122, 132, 150]
        };
        let indent = if i % 3 == 0 { 0 } else { 26 };
        c.rect(248 + indent, y, width_at(i as u32 + 71, 140, 640 - indent), 8, color);
    }

    // Pasek postepu: rosnie z kazda klatka.
    let track_w = 680usize;
    c.rect(248, H - 62, track_w, 8, [42, 49, 62]);
    let fill = track_w * frame / (FRAMES - 1);
    c.rect(248, H - 62, fill, 8, [72, 176, 124]);

    // Dolny pasek statusu.
    c.rect(0, H - 32, W, 32, [18, 22, 30]);
    c.rect(16, H - 20, 86, 6, [64, 74, 90]);
    c.rect(W - 150, H - 20, 60, 6, [64, 74, 90]);
    c.rect(W - 76, H - 20, 40, 6, [72, 176, 124]);
}

// --- PNG -------------------------------------------------------------------

fn write_chunk(out: &mut Vec<u8>, kind: &[u8; 4], data: &[u8]) {
    out.extend_from_slice(&(data.len() as u32).to_be_bytes());
    out.extend_from_slice(kind);
    out.extend_from_slice(data);
    let mut crc_input = Vec::with_capacity(4 + data.len());
    crc_input.extend_from_slice(kind);
    crc_input.extend_from_slice(data);
    out.extend_from_slice(&crc32(&crc_input).to_be_bytes());
}

/// Strumien zlib z niezwartymi blokami deflate (bez zaleznosci).
fn zlib_stored(raw: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(raw.len() + raw.len() / 65_535 * 5 + 16);
    out.extend_from_slice(&[0x78, 0x01]);
    let mut chunks = raw.chunks(65_535).peekable();
    if chunks.peek().is_none() {
        out.extend_from_slice(&[0x01, 0x00, 0x00, 0xff, 0xff]);
    }
    while let Some(chunk) = chunks.next() {
        let last = chunks.peek().is_none();
        out.push(if last { 0x01 } else { 0x00 });
        let len = chunk.len() as u16;
        out.extend_from_slice(&len.to_le_bytes());
        out.extend_from_slice(&(!len).to_le_bytes());
        out.extend_from_slice(chunk);
    }
    out.extend_from_slice(&adler32(raw).to_be_bytes());
    out
}

fn adler32(data: &[u8]) -> u32 {
    let (mut a, mut b) = (1u32, 0u32);
    for byte in data {
        a = (a + *byte as u32) % 65_521;
        b = (b + a) % 65_521;
    }
    (b << 16) | a
}

fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for byte in data {
        crc ^= *byte as u32;
        for _ in 0..8 {
            let mask = (crc & 1).wrapping_neg();
            crc = (crc >> 1) ^ (0xedb8_8320 & mask);
        }
    }
    !crc
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn screenshot_is_a_non_blank_png() {
        let dir = std::env::temp_dir().join(format!("arndtai-shot-{}", std::process::id()));
        let path = dir.join("now.png");
        let code = save(path.to_str().unwrap());
        assert_eq!(code, 0);
        let bytes = fs::read(&path).unwrap();
        assert_eq!(&bytes[..8], &[0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a]);
        assert!(bytes.len() > 10_000, "zrzut nie moze byc pusty");

        // Nie-blank: sa co najmniej dwa rozne kolory.
        let mut c = Canvas::new(W, H);
        draw(&mut c, FRAMES - 1);
        let first = &c.px[..3];
        assert!(c.px.chunks(3).any(|p| p != first));
        let _ = fs::remove_dir_all(&dir);
    }
}
