//! Kontekst agenta: osobowość, skille i pamięć projektu plus transkrypty sesji.
//!
//! Poziomy pamięci wg docs/02-memory.md:
//! - Lite: surowy log sesji + wyszukiwanie (project.md).
//! - Pro:  + fakty i epizody (facts.md, episodes.md).
//! - Ultra: + konsolidacja (graph.md).

use serde_json::{json, Value};
use std::fs;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

pub const DEFAULT_PERSONA: &str = "\
Jestes ArndtAi — dzienny doradca Kamila. Mow po polsku, wprost, po kumplowemu.\
 Pierwsze zdanie to wynik albo decyzja, nie temat. Domyslnie 3-5 linii.\
 Zero emoji. Kazda liczba musi pochodzic z narzedzia, nie z pamieci.\
 Brak danych: mowisz czego brakuje i skad to wezmiesz. Nie wymyslaj wynikow.";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MemoryLevel {
    Lite,
    Pro,
    Ultra,
}

impl MemoryLevel {
    pub fn parse(text: &str) -> Option<MemoryLevel> {
        match text.trim().to_ascii_lowercase().as_str() {
            "lite" => Some(MemoryLevel::Lite),
            "pro" => Some(MemoryLevel::Pro),
            "ultra" => Some(MemoryLevel::Ultra),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            MemoryLevel::Lite => "lite",
            MemoryLevel::Pro => "pro",
            MemoryLevel::Ultra => "ultra",
        }
    }
}

pub struct Skill {
    pub name: String,
    pub summary: String,
    pub path: PathBuf,
}

pub struct Prefix {
    pub persona: String,
    pub persona_source: String,
    pub skills: Vec<Skill>,
    pub memory: Option<String>,
    pub memory_source: Option<String>,
    pub memory_level: MemoryLevel,
}

impl Prefix {
    pub fn load(workspace: &Path, level: MemoryLevel) -> Prefix {
        let persona_candidates = [
            "personality/base.md",
            ".agent/personality/base.md",
            "personality.md",
            "PERSONALITY.md",
            "PERSONA.md",
            "persona.md",
            "arndtai/personality.md",
        ];
        let mut persona = DEFAULT_PERSONA.to_string();
        let mut persona_source = "wbudowana".to_string();
        for cand in persona_candidates.iter() {
            if let Some(text) = read_nonempty(&workspace.join(cand)) {
                persona = text;
                persona_source = cand.to_string();
                break;
            }
        }

        let mut parts: Vec<String> = Vec::new();
        let mut sources: Vec<String> = Vec::new();
        for cand in memory_candidates(level) {
            if let Some(text) = read_nonempty(&workspace.join(cand)) {
                parts.push(format!("--- {} ---\n{}", cand, text.trim()));
                sources.push(cand.to_string());
            }
        }
        let memory = if parts.is_empty() {
            None
        } else {
            Some(parts.join("\n\n"))
        };
        let memory_source = if sources.is_empty() {
            None
        } else {
            Some(sources.join(", "))
        };

        Prefix {
            persona,
            persona_source,
            skills: scan_skills(&workspace.join("skills")),
            memory,
            memory_source,
            memory_level: level,
        }
    }

    pub fn render(&self) -> String {
        let mut out = String::new();
        out.push_str("=== OSOBOWOSC ===\n");
        out.push_str(self.persona.trim());
        out.push_str(&format!("\n(zrodlo: {})\n", self.persona_source));

        out.push_str("\n=== SKILLE ===\n");
        if self.skills.is_empty() {
            out.push_str("brak skilli w skills/\n");
        } else {
            for s in self.skills.iter() {
                out.push_str(&format!("- {}: {}\n", s.name, s.summary));
            }
        }

        out.push_str(&format!(
            "\n=== PAMIEC PROJEKTU (poziom {}) ===\n",
            self.memory_level.as_str()
        ));
        match (&self.memory, &self.memory_source) {
            (Some(text), Some(src)) => {
                out.push_str(text);
                out.push_str(&format!("\n(zrodlo: {})\n", src));
            }
            _ => out.push_str("brak pliku pamieci\n"),
        }
        out
    }
}

/// Pliki pamięci czytane na danym poziomie, w kolejności.
fn memory_candidates(level: MemoryLevel) -> Vec<&'static str> {
    let mut out = vec![
        ".agent-memory/project.md",
        "memory/project.md",
        ".agent/memory/project.md",
    ];
    if matches!(level, MemoryLevel::Pro | MemoryLevel::Ultra) {
        out.push("memory/facts.md");
        out.push(".agent-memory/facts.md");
        out.push("memory/episodes.md");
        out.push(".agent-memory/episodes.md");
    }
    if level == MemoryLevel::Ultra {
        out.push("memory/graph.md");
        out.push(".agent-memory/graph.md");
    }
    out
}

fn read_nonempty(path: &Path) -> Option<String> {
    let text = fs::read_to_string(path).ok()?;
    if text.trim().is_empty() {
        None
    } else {
        Some(text)
    }
}

fn scan_skills(root: &Path) -> Vec<Skill> {
    let mut found = Vec::new();
    let entries = match fs::read_dir(root) {
        Ok(e) => e,
        Err(_) => return found,
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let skill_md = path.join("SKILL.md");
        let text = match fs::read_to_string(&skill_md) {
            Ok(t) => t,
            Err(_) => continue,
        };
        let mut name = path
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("skill")
            .to_string();
        let mut summary = String::new();
        for line in text.lines() {
            let trimmed = line.trim();
            if trimmed.is_empty() {
                continue;
            }
            if let Some(heading) = trimmed.strip_prefix("# ") {
                if name.is_empty() || name == "skill" {
                    name = heading.trim().to_string();
                }
                continue;
            }
            if trimmed.starts_with('#') {
                continue;
            }
            summary = trimmed.chars().take(140).collect();
            break;
        }
        if summary.is_empty() {
            summary = "(brak opisu)".to_string();
        }
        found.push(Skill {
            name,
            summary,
            path: skill_md,
        });
    }
    found.sort_by(|a, b| a.name.cmp(&b.name));
    found
}

pub fn now_ts() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

pub struct Session {
    pub id: String,
    pub file: PathBuf,
}

impl Session {
    pub fn start(workspace: &Path, task: &str) -> Session {
        let dir = workspace.join(".agent").join("sessions");
        let _ = fs::create_dir_all(&dir);
        let ts = now_ts();
        let mut id = ts.to_string();
        let mut file = dir.join(format!("{}.jsonl", id));
        let mut n = 1;
        while file.exists() {
            id = format!("{}-{}", ts, n);
            file = dir.join(format!("{}.jsonl", id));
            n += 1;
        }
        let session = Session { id, file };
        session.event("task", json!({ "text": task }));
        session
    }

    /// Wznowienie istniejacej sesji: ten sam `id`, ten sam plik transkryptu.
    /// Bez tego po restarcie powstaje nowy `session_id` i kroki `done` nigdy
    /// sie nie odnajda.
    pub fn resume(workspace: &Path, id: &str) -> Session {
        let dir = workspace.join(".agent").join("sessions");
        let _ = fs::create_dir_all(&dir);
        Session {
            id: id.to_string(),
            file: dir.join(format!("{}.jsonl", id)),
        }
    }

    pub fn event(&self, kind: &str, data: Value) {
        let line = json!({ "at": now_ts(), "kind": kind, "data": data }).to_string();
        if let Ok(mut f) = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.file)
        {
            use std::io::Write;
            let _ = f.write_all(format!("{}\n", line).as_bytes());
        }
    }
}

/// Lista transkryptów w workspace, od najstarszego.
pub fn sessions(workspace: &Path) -> Vec<PathBuf> {
    let dir = workspace.join(".agent").join("sessions");
    let mut out = Vec::new();
    if let Ok(entries) = fs::read_dir(&dir) {
        for entry in entries.flatten() {
            let p = entry.path();
            if p.extension().and_then(|x| x.to_str()) == Some("jsonl") {
                out.push(p);
            }
        }
    }
    out.sort();
    out
}
