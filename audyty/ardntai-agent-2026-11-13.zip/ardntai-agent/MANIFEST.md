# Paczka do audytu — ArndtAi (agent) — 2026-11-13

## Co to jest

Wycinek projektu `/home/karndt/projects/ArndtAi` zawierający **wyłącznie zbudowanego agenta** (kod, testy, kontrakty, bramki akceptacji) oraz skompilowaną binarkę. Bez stanu runtime, cache builda i artefaktów procesu.

- Źródło: `/home/karndt/projects/ArndtAi` (katalog nie jest repozytorium git — brak commita; tożsamość drzewa = `SHA256SUMS`)
- Data pakowania: 2026-11-13 11:57 UTC
- Układ źródłowy: kod w `app/`, dokumenty decyzyjne w `docs/` (patrz `README.md` projektu)

## Zawartość

```
ardntai-agent/
  README.md                     # co to jest, jak uruchomić, gwarancje
  GATES.md                      # bramki akceptacji G1..Gn z dowodami (exit code + hashe)
  MANIFEST.md                   # ten plik
  SHA256SUMS                    # hashe 23 plików (bez samego SHA256SUMS)
  bin/ardntai                   # release build (Rust, x86_64-linux), 3,1 MB
  agent/
    Cargo.toml, Cargo.lock      # deps: serde_json 1, rusqlite 0.32 (bundled)
    src/*.rs                    # 9 modułów, 4331 linii: agent, context, main, mcp,
                                #   provider, schema, shot, store, tools
    tests/cli.rs                # 4 testy integracyjne CLI
    docs/AGENT-TEST.md          # notatka testowa
  docs/
    contracts/mcp.md            # koperta wywołań, kody błędów
    contracts/events.md         # schemat eventów i tabel
    architecture/adr/ADR-001..003
    re/README.md                # decyzje, odstępstwa, znane braki
```

## Dowód, że paczka jest kompletna i buduje się sama

Uruchomione na **kopii paczki** w czystym katalogu (`/home/karndt/.hermes/cache/scratch/ardntai-pkg-check/agent`), bez dostępu do `target/` projektu:

| komenda | wynik |
|---|---|
| `cargo test --offline` | `34 passed; 0 failed` (unit) + `4 passed; 0 failed` (integration), exit 0 |
| `cargo build --release --offline` | `Finished release profile in 45.79s`, binarka 3,1 MB |
| `sha256sum -c SHA256SUMS` | patrz `SHA256SUMS` — 22/22 plików |

## Czego w paczce nie ma (i dlaczego)

| wykluczone | powód |
|---|---|
| `app/target/` (260 MB) | cache kompilacji; odtwarzalny z `Cargo.toml` + `Cargo.lock` |
| `app/.agent/` (`state.db`, `sessions/`, `outbox/`, `resume`) | stan runtime i transkrypty przebiegów — nie kod agenta |
| `app/alias` | symlink testowy `alias -> .agent` (fixture testu sandboxu) |
| `app/shots/*.png` (3,1 MB) | artefakty zrzutów ekranu, nie część agenta |
| `craft-anything-input/` (80 KB) | materiał wejściowy / spec 00-09 — kryteria, nie kod; zostaje w projekcie |
| `investigation.cany/` (1 MB) | pamięć investigacji Craft Anything |
| `capture/`, `audyty/`, `*.jsonl`, `*.log`, `*.zip` | artefakty procesu i wcześniejszy audyt |

## Jak sprawdzić paczkę

```sh
sha256sum -c SHA256SUMS
cd agent && cargo test --offline
./bin/ardntai demo
```

## Ograniczenia

- Brak podpisu i brak łańcucha custody poza `SHA256SUMS`; źródło nie ma historii git, więc nie da się wskazać commita.
- Binarka zbudowana lokalnie (rustc 1.99.1, target x86_64-unknown-linux-gnu); nie jest reprodukowalna bit-w-bit bez tego samego toolchainu.
- `docs/re/README.md` to notatka decyzyjna projektu, nie pełny raport reverse-engineeringu z 09 §0.
