//! Pętla agenta: decyzja -> bramki -> wykonanie -> obserwacja -> warunek stopu.
//!
//! Bramki w kolejności: allowlista narzędzi, scope guard, detektor dryfu.
//! Wywołania narzędzi idą przez perimeter MCP (osobny proces) albo wprocesowo.

use crate::context::{MemoryLevel, Prefix, Session};
use crate::mcp::McpClient;
use crate::provider::{Action, Brain, Turn};
use crate::store::Store;
use crate::tools;
use serde_json::json;
use std::path::PathBuf;

pub struct Config {
    pub workspace: PathBuf,
    pub max_steps: usize,
    pub allowlist: Vec<String>,
    pub provider: Option<String>,
    pub quiet: bool,
    pub mcp: bool,
    pub memory: MemoryLevel,
    /// Wznowienie po `crashu`: sesja i kroki z `.agent/resume` + SQLite.
    pub resume: bool,
}

pub struct Report {
    pub status: String,
    pub steps: usize,
    pub tool_calls: usize,
    pub denied: usize,
    pub drift: usize,
    pub reason: String,
    pub session: PathBuf,
}

struct Outcome {
    status: &'static str,
    reason: String,
    steps: usize,
    tool_calls: usize,
    denied: usize,
    drift: usize,
}

fn emit(cfg: &Config, stage: &str, detail: &str) {
    if !cfg.quiet {
        println!("  [{}] {}", stage, detail);
    }
}

fn short(text: &str, limit: usize) -> String {
    if text.chars().count() <= limit {
        text.to_string()
    } else {
        let clipped: String = text.chars().take(limit).collect();
        format!("{}...", clipped)
    }
}

pub fn run(task: &str, cfg: &Config) -> Report {
    let prefix = Prefix::load(&cfg.workspace, cfg.memory);
    let rendered = prefix.render();
    let transport = if cfg.mcp { "mcp" } else { "wprocesowy" };

    // F8: wznowienie musi trafic w te sama sesje, inaczej (session_id, step_id)
    // nigdy sie nie spotka i `done` nie zostanie odczytane.
    let resume_id = if cfg.resume {
        crate::read_resume_pointer(&cfg.workspace)
    } else {
        None
    };
    if cfg.resume && resume_id.is_none() {
        let session = Session::start(&cfg.workspace, task);
        session.event(
            "error",
            json!({ "message": "brak .agent/resume — nie ma czego wznawiac" }),
        );
        return finish(
            cfg,
            &session,
            transport,
            Outcome {
                status: "FAILED_ERROR",
                reason: "brak .agent/resume — nie ma czego wznawiac".to_string(),
                steps: 0,
                tool_calls: 0,
                denied: 0,
                drift: 0,
            },
        );
    }
    let session = match resume_id {
        Some(id) => Session::resume(&cfg.workspace, &id),
        None => Session::start(&cfg.workspace, task),
    };
    crate::write_resume_pointer(&cfg.workspace, &session.id);

    // Faza B: SQLite store — idempotencja + resume. Brak store = praca bez
    // persistencji (ostrzezenie, nie twardy blad, zeby demo nie padalo).
    let store = Store::for_workspace(&cfg.workspace);
    let store_ok = match store.init().and_then(|_| store.create_session(&session.id, task)) {
        Ok(()) => true,
        Err(e) => {
            eprintln!("ostrzezenie: SQLite niedostepny ({}), lece bez resume", e);
            false
        }
    };

    if store_ok {
        session.event(
            "store",
            json!({
                "path": ".agent/state.db",
                "journal_mode": store.journal_mode().unwrap_or_else(|e| format!("error: {}", e)),
                "busy_timeout": store.busy_timeout().unwrap_or(-1),
            }),
        );
    }

    let mut brain = Brain::from_env(cfg.provider.as_deref(), task, &cfg.allowlist);
    let brain_label = brain.label();
    let brain_note = brain.note().map(|s| s.to_string());
    if !cfg.quiet {
        println!("ArndtAi — agent wykonawczy");
        println!("Zadanie: {}", task);
        println!("Folder: {}", cfg.workspace.display());
        println!("Mozg: {}", brain_label);
        if let Some(note) = brain_note.as_deref() {
            println!("Uwaga: {}", note);
        }
        println!("Perimetr: {}", transport);
        println!("Poziom pamieci: {}", cfg.memory.as_str());
        println!();
    }

    let mut client = if cfg.mcp {
        match McpClient::spawn(&cfg.workspace) {
            Ok(c) => Some(c),
            Err(e) => {
                let reason = format!("perimeter MCP nie wystartowal: {}", e);
                emit(cfg, "FAILED_ERROR", &reason);
                session.event("error", json!({ "message": reason.clone() }));
                return finish(
                    cfg,
                    &session,
                    transport,
                    Outcome {
                        status: "FAILED_ERROR",
                        reason,
                        steps: 0,
                        tool_calls: 0,
                        denied: 0,
                        drift: 0,
                    },
                );
            }
        }
    } else {
        None
    };

    let allowlist = cfg.allowlist.clone();
    let mut turns: Vec<Turn> = Vec::new();
    let mut steps: usize = 0;
    let mut tool_calls: usize = 0;
    let mut denied: usize = 0;
    let mut drift: usize = 0;
    let mut streak: usize = 0;
    // Odcisk (tool+args) ostatnich wykonanych wywolan; okno = biezace + 3 poprzednie.
    let mut recent: Vec<String> = Vec::new();

    let outcome: Outcome = 'steps: loop {
        if steps >= cfg.max_steps {
            break 'steps Outcome {
                status: "FAILED_BUDGET",
                reason: format!("budzet krokow wyczerpany ({})", cfg.max_steps),
                steps,
                tool_calls,
                denied,
                drift,
            };
        }
        steps += 1;

        emit(cfg, "RECEIVED", &format!("krok {}", steps));
        let decision = match brain.next(task, &rendered, &turns) {
            Ok(d) => d,
            Err(e) => {
                emit(cfg, "FAILED_ERROR", &e);
                session.event("error", json!({ "message": e.clone() }));
                break 'steps Outcome {
                    status: "FAILED_ERROR",
                    reason: e,
                    steps,
                    tool_calls,
                    denied,
                    drift,
                };
            }
        };
        emit(cfg, "PLANNING", &decision.thought);
        session.event(
            "thought",
            json!({ "step": steps, "thought": decision.thought }),
        );

        match decision.action {
            Action::Finish { summary } => {
                emit(cfg, "DONE", &summary);
                break 'steps Outcome {
                    status: "DONE",
                    reason: summary,
                    steps,
                    tool_calls,
                    denied,
                    drift,
                };
            }
            Action::Tool { name, args } => {
                emit(cfg, "STEP_PROPOSED", &name);
                emit(cfg, "POLICY_CHECK", &name);
                let allowed = allowlist.iter().any(|a| a == &name);

                emit(cfg, "SCOPE_CHECK", &name);
                let scope_error = match tools::path_arg(&args) {
                    Some(rel) => tools::resolve(&cfg.workspace, &rel).err().map(|e| e.summary()),
                    None => None,
                };

                let fingerprint = format!("{}|{}", name, args);
                // F11: dryf to powtorzenie odcisku w oknie ostatnich 4 wywolan,
                // nie tylko bezposrednio po poprzednim (A,B,A,B tez jest dryfem).
                let repeats = recent.iter().filter(|f| *f == &fingerprint).count() + 1;
                let is_drift = repeats >= 2;

                let denial = if !allowed {
                    Some(format!("{} nie jest na allowliscie", name))
                } else if let Some(e) = scope_error {
                    Some(format!("{} odrzucone przez bramke zakresu: {}", name, e))
                } else if is_drift {
                    Some(format!(
                        "{} powtarza odcisk (tool+args) w oknie 4 wywolan bez zmiany (dryf)",
                        name
                    ))
                } else {
                    None
                };

                if let Some(message) = denial {
                    denied += 1;
                    streak += 1;
                    if is_drift {
                        drift += 1;
                    }
                    emit(cfg, "OBSERVE", &format!("odmowa: {}", message));
                    session.event(
                        "denied",
                        json!({ "step": steps, "tool": name, "reason": message, "drift": is_drift }),
                    );
                    turns.push(Turn {
                        role: "tool".to_string(),
                        content: format!("{} ok=false -> {}", name, message),
                    });
                    if streak >= 3 {
                        break 'steps Outcome {
                            status: "FAILED_STALLED",
                            reason: format!("{} odmow z rzedu", streak),
                            steps,
                            tool_calls,
                            denied,
                            drift,
                        };
                    }
                    continue 'steps;
                }

                // F2/F4/F8: przed efektem ubocznym krok jest `proposed`; jesli
                // wiersz juz istnieje — replay wyniku albo skip po crashu.
                let step_id = steps as u64;
                let args_json = args.to_string();
                let mut replay: Option<String> = None;
                let mut abandoned = false;
                // Przy transporcie MCP kroki zapisuje serwer perimetru (ten sam
                // `state.db`); rdzen nie dubluje wlasnego `proposed`, bo to
                // wygladaloby jak crash i krok zostalby pominiety.
                if store_ok && !cfg.mcp {
                    // Najpierw czytamy wiersz SPRZED tego przebiegu: swiezo
                    // wstawiony `proposed` nie jest crashem.
                    let prior = store.fetch_step(&session.id, step_id);
                    match prior {
                        Ok(Some(row)) => {
                            let same = row.tool == name && row.args_json == args_json;
                            if same && row.status == "done" {
                                replay = Some(row.result_json.unwrap_or_else(|| "{}".to_string()));
                            } else if row.status == "proposed" || (same && row.status == "abandoned")
                            {
                                let note =
                                    json!({ "skipped": "crash_before_result" }).to_string();
                                if row.status == "proposed" {
                                    if let Err(e) =
                                        store.mark_abandoned(&session.id, step_id, &note)
                                    {
                                        session.event(
                                            "store_error",
                                            json!({ "stage": "abandoned", "message": e }),
                                        );
                                    }
                                }
                                abandoned = true;
                            } else if let Err(e) =
                                store.proposed(&session.id, step_id, &name, &args_json)
                            {
                                session.event(
                                    "store_error",
                                    json!({ "stage": "proposed", "message": e }),
                                );
                            }
                        }
                        Ok(None) => {
                            if let Err(e) = store.proposed(&session.id, step_id, &name, &args_json)
                            {
                                session.event(
                                    "store_error",
                                    json!({ "stage": "proposed", "message": e }),
                                );
                            }
                        }
                        Err(e) => {
                            session.event("store_error", json!({ "stage": "fetch", "message": e }))
                        }
                    }
                }

                if let Some(cached) = replay {
                    emit(cfg, "OBSERVE", &format!("{} cached (krok {} juz wykonany)", name, step_id));
                    session.event(
                        "tool_result_cached",
                        json!({ "step": steps, "tool": name, "result": cached }),
                    );
                    turns.push(Turn {
                        role: "tool".to_string(),
                        content: format!("{} ok=true -> {} (z zapisanego kroku)", name, cached),
                    });
                    continue 'steps;
                }

                if abandoned {
                    emit(cfg, "OBSERVE", &format!("{} skipped (crash przed wynikiem)", name));
                    session.event(
                        "tool_result_skipped",
                        json!({ "step": steps, "tool": name, "reason": "crash_before_result" }),
                    );
                    turns.push(Turn {
                        role: "tool".to_string(),
                        content: format!(
                            "{} ok=false -> SKIPPED: krok przerwany przed wynikiem, nie powtarzam (at-most-once)",
                            name
                        ),
                    });
                    continue 'steps;
                }

                emit(cfg, "EXECUTING", &name);
                session.event("tool_call", json!({ "step": steps, "tool": name, "args": args }));

                let ctx = tools::CallCtx {
                    task_id: session.id.clone(),
                    session_id: session.id.clone(),
                    step_id: steps as u64,
                };
                let result = match client.as_mut() {
                    Some(c) => match c.call(&name, &args, &ctx) {
                        Ok(r) => r,
                        Err(e) => tools::ToolResult::error("IO_ERROR", e),
                    },
                    None => tools::call(&name, &args, &cfg.workspace),
                };
                if store_ok && !cfg.mcp {
                    let result_json = json!({
                        "ok": result.ok,
                        "code": result.code,
                        "bytes": result.bytes,
                        "output": result.output,
                    })
                    .to_string();
                    let persisted = if name == "notify.send" && result.ok {
                        store.complete_with_outbox(&session.id, step_id, &result_json, &args_json)
                    } else {
                        store.complete(&session.id, step_id, &result_json)
                    };
                    if let Err(e) = persisted {
                        session.event("store_error", json!({ "stage": "complete", "message": e }));
                    }
                }
                tool_calls += 1;
                recent.push(fingerprint);
                if recent.len() > 3 {
                    recent.remove(0);
                }
                if result.ok {
                    streak = 0;
                } else {
                    streak += 1;
                }

                emit(
                    cfg,
                    "OBSERVE",
                    &format!("{} ok={} ({} bajtow)", name, result.ok, result.bytes),
                );
                session.event(
                    "tool_result",
                    json!({
                        "step": steps,
                        "tool": name,
                        "ok": result.ok,
                        "code": result.code,
                        "bytes": result.bytes,
                        "output": result.output,
                    }),
                );
                turns.push(Turn {
                    role: "tool".to_string(),
                    content: format!(
                        "{} ok={} -> {}",
                        name,
                        result.ok,
                        short(&result.summary(), 600)
                    ),
                });

                if streak >= 3 {
                    break 'steps Outcome {
                        status: "FAILED_STALLED",
                        reason: format!("{} nieudanych krokow z rzedu", streak),
                        steps,
                        tool_calls,
                        denied,
                        drift,
                    };
                }
                emit(cfg, "STOP_CHECK", "kontynuuje");
            }
        }
    };

    if let Some(mut c) = client.take() {
        c.shutdown();
    }

    finish(cfg, &session, transport, outcome)
}

fn finish(cfg: &Config, session: &Session, transport: &str, outcome: Outcome) -> Report {
    session.event(
        "summary",
        json!({
            "status": outcome.status,
            "steps": outcome.steps,
            "tool_calls": outcome.tool_calls,
            "denied": outcome.denied,
            "drift": outcome.drift,
            "reason": outcome.reason,
        }),
    );
    if !cfg.quiet {
        println!();
        println!("Status: {}", outcome.status);
        println!("Kroki: {}", outcome.steps);
        println!("Narzedzia: {}", outcome.tool_calls);
        println!("Odmowy: {}", outcome.denied);
        println!("Dryf: {}", outcome.drift);
        println!("Powod: {}", outcome.reason);
        println!("Perimetr: {}", transport);
        println!("Transkrypt: {}", session.file.display());
    }
    Report {
        status: outcome.status.to_string(),
        steps: outcome.steps,
        tool_calls: outcome.tool_calls,
        denied: outcome.denied,
        drift: outcome.drift,
        reason: outcome.reason,
        session: session.file.clone(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::store::Store;
    use std::fs;

    fn unique_suffix() -> String {
        use std::time::{SystemTime, UNIX_EPOCH};
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        format!("{}-{}", n, std::process::id())
    }

    fn temp_ws(tag: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "arndtai-agent-{}-{}-{}",
            tag,
            std::process::id(),
            unique_suffix()
        ));
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    fn config(workspace: &PathBuf, resume: bool) -> Config {
        Config {
            workspace: workspace.clone(),
            max_steps: 8,
            allowlist: tools::NAMES.iter().map(|n| n.to_string()).collect(),
            provider: Some("mock".to_string()),
            quiet: true,
            mcp: false,
            memory: MemoryLevel::Lite,
            resume,
        }
    }

    fn transcript_has(session_file: &PathBuf, needle: &str) -> bool {
        fs::read_to_string(session_file)
            .map(|s| s.contains(needle))
            .unwrap_or(false)
    }

    #[test]
    fn step_is_persisted_after_run() {
        let ws = temp_ws("persist");
        let report = run("write out.txt :: alfa", &config(&ws, false));
        assert_eq!(report.status, "DONE", "{}", report.reason);
        assert_eq!(fs::read_to_string(ws.join("out.txt")).unwrap(), "alfa");

        let store = Store::for_workspace(&ws);
        store.init().unwrap();
        let id = crate::read_resume_pointer(&ws).expect("wskaznik .agent/resume");
        let steps = store.steps_for_session(&id).unwrap();
        assert_eq!(steps.len(), 1, "krok musi trafic do tabeli steps");
        assert_eq!(steps[0].status, "done");
        assert!(steps[0].result_json.is_some(), "wynik kroku musi byc zapisany");
        let _ = fs::remove_dir_all(&ws);
    }

    #[test]
    fn resume_skips_done_step_without_repeating_effect() {
        let ws = temp_ws("resume-done");
        let first = run("write out.txt :: alfa", &config(&ws, false));
        assert_eq!(first.status, "DONE", "{}", first.reason);

        let second = run("write out.txt :: alfa", &config(&ws, true));
        assert_eq!(second.status, "DONE", "{}", second.reason);
        assert_eq!(fs::read_to_string(ws.join("out.txt")).unwrap(), "alfa");
        assert!(
            transcript_has(&second.session, "tool_result_cached"),
            "wznowienie musi uzyc zapisanego wyniku"
        );

        let store = Store::for_workspace(&ws);
        store.init().unwrap();
        let id = crate::read_resume_pointer(&ws).unwrap();
        assert_eq!(store.steps_for_session(&id).unwrap().len(), 1, "bez duplikatu kroku");
        let _ = fs::remove_dir_all(&ws);
    }

    #[test]
    fn resume_marks_proposed_step_abandoned_without_executing() {
        let ws = temp_ws("resume-proposed");
        let store = Store::for_workspace(&ws);
        store.init().unwrap();
        store.create_session("sesja-proposed", "write out.txt :: alfa").unwrap();
        store
            .proposed(
                "sesja-proposed",
                1,
                "fs.write",
                &json!({"content":"alfa","path":"out.txt"}).to_string(),
            )
            .unwrap();
        fs::create_dir_all(ws.join(".agent")).unwrap();
        fs::write(ws.join(".agent/resume"), "sesja-proposed").unwrap();

        let report = run("write out.txt :: alfa", &config(&ws, true));
        assert_eq!(report.status, "DONE", "{}", report.reason);
        assert!(
            !ws.join("out.txt").exists(),
            "krok 'proposed' po crashu nie moze wykonac sie automatycznie (at-most-once)"
        );
        assert!(
            transcript_has(&report.session, "tool_result_skipped"),
            "pominiecie musi byc widoczne w transkrypcie"
        );
        let steps = store.steps_for_session("sesja-proposed").unwrap();
        assert_eq!(steps[0].status, "abandoned");
        let _ = fs::remove_dir_all(&ws);
    }

    #[test]
    fn drift_detects_alternating_repeat_in_window() {
        let ws = temp_ws("drift-window");
        fs::write(ws.join("a.txt"), "alfa").unwrap();
        fs::write(ws.join("b.txt"), "beta").unwrap();
        // A,B,A,B: ten sam odcisk (tool+args) wraca w oknie 4 wywolan, choc
        // bezposrednio poprzednie wywolanie jest inne.
        let report = run(
            "read a.txt; read b.txt; read a.txt; read b.txt",
            &config(&ws, false),
        );
        assert!(
            report.drift >= 1,
            "A,B,A,B musi byc dryfem (drift={})",
            report.drift
        );
        assert!(
            report.tool_calls < 4,
            "dryf musi zatrzymac powtorzone wywolanie (tool_calls={})",
            report.tool_calls
        );
        let _ = fs::remove_dir_all(&ws);
    }

    #[test]
    fn notify_writes_outbox_row_in_step_transaction() {
        let ws = temp_ws("outbox");
        let report = run("notify hej", &config(&ws, false));
        assert_eq!(report.status, "DONE", "{}", report.reason);
        let store = Store::for_workspace(&ws);
        store.init().unwrap();
        let id = crate::read_resume_pointer(&ws).unwrap();
        let rows = store.outbox_for_session(&id).unwrap();
        assert_eq!(rows.len(), 1, "notify.send musi trafic do tabeli outbox");
        assert!(rows[0].contains("hej"));
        let steps = store.steps_for_session(&id).unwrap();
        assert_eq!(steps[0].status, "done");
        assert_eq!(steps[0].tool, "notify.send");
        let _ = fs::remove_dir_all(&ws);
    }
}
