//! ArndtAi — agent terminalowy.
//!
//! `mcp` to perimeter wystawiony po stdio (kontrakt docs/contracts/mcp.md v0.1),
//! `run` to pętla agenta, `demo` to zestaw sprawdzeń na realnych artefaktach.

mod agent;
mod context;
mod mcp;
mod provider;
mod schema;
mod shot;
mod store;
mod tools;

use serde_json::json;
use std::path::{Path, PathBuf};

fn main() {
    std::process::exit(run_cli());
}

fn run_cli() -> i32 {
    let args: Vec<String> = std::env::args().skip(1).collect();
    // Zrzut do PNG: tryb bezobslugowy, konczy sie po zapisaniu pliku.
    if args
        .iter()
        .any(|a| a == "--screenshot" || a.starts_with("--screenshot="))
    {
        return match screenshot_arg(&args) {
            Some(path) => shot::save(&path),
            None => {
                eprintln!("--screenshot wymaga sciezki pliku .png");
                2
            }
        };
    }
    if args.is_empty() {
        usage();
        return 0;
    }
    match args[0].as_str() {
        "help" | "-h" | "--help" => {
            usage();
            0
        }
        "mcp" => serve_mcp(&args[1..]),
        "tools" => {
            list_tools();
            0
        }
        "skills" => match memory_arg(&args[1..], "skills") {
            Ok(level) => {
                list_skills(level);
                0
            }
            Err(code) => code,
        },
        "status" => match memory_arg(&args[1..], "status") {
            Ok(level) => {
                status(level);
                0
            }
            Err(code) => code,
        },
        "demo" => demo(),
        "run" => {
            if args.len() < 2 {
                usage();
                return 2;
            }
            run_task(&args[1..])
        }
        _ => run_task(&args),
    }
}

fn screenshot_arg(args: &[String]) -> Option<String> {
    for (i, arg) in args.iter().enumerate() {
        if arg == "--screenshot" {
            return args.get(i + 1).cloned();
        }
        if let Some(path) = arg.strip_prefix("--screenshot=") {
            return Some(path.to_string());
        }
    }
    None
}

/// F23: poziom pamieci dla komend pomocniczych — ta sama flaga i te same
/// wartosci co w `run` (`--memory lite|pro|ultra` oraz `--memory=pro`).
/// Domyslnie `lite`, tak jak dotad.
fn memory_arg(args: &[String], command: &str) -> Result<context::MemoryLevel, i32> {
    let mut level = context::MemoryLevel::Lite;
    let mut i = 0;
    while i < args.len() {
        let arg = args[i].as_str();
        let raw = match arg {
            "--memory" => match args.get(i + 1) {
                Some(v) => {
                    i += 2;
                    v.as_str()
                }
                None => {
                    eprintln!("--memory wymaga poziomu (lite|pro|ultra)");
                    return Err(2);
                }
            },
            other if other.starts_with("--memory=") => {
                i += 1;
                &other["--memory=".len()..]
            }
            other => {
                eprintln!("nieznany argument {}: {}", command, other);
                return Err(2);
            }
        };
        match context::MemoryLevel::parse(raw) {
            Some(parsed) => level = parsed,
            None => {
                eprintln!("--memory: dozwolone lite, pro, ultra");
                return Err(2);
            }
        }
    }
    Ok(level)
}

fn usage() {
    println!("ArndtAi 0.1 — agent terminalowy");
    println!();
    println!("  arndtai run \"zadanie\" [--provider mock|anthropic|openai] [--workspace FOLDER]");
    println!("                [--steps N] [--memory lite|pro|ultra] [--mcp|--no-mcp] [-q]");
    println!("  arndtai demo      — sprawdzenia: petla z narzedziami, scope guard, allowlista,");
    println!("                      MCP, kontrakt narzedzi, dryf, poziomy pamieci");
    println!("  arndtai mcp [--workspace FOLDER]   — serwer MCP po stdio (perimeter)");
    println!("  arndtai tools     — lista narzedzi perimeteru");
    println!("  arndtai skills [--memory lite|pro|ultra]  — osobowosc, skille i pamiec projektu");
    println!("  arndtai status [--memory lite|pro|ultra]  — stan workspace'u (sesje, mozg, outbox)");
    println!();
    println!("TRYB PRACY");
    println!("  offline (mock): \"read plik; write plik :: tresc; notify komunikat\"");
    println!("  zdalny: ANTHROPIC_API_KEY albo OPENAI_API_KEY (opcjonalnie ARNDTAI_MODEL,");
    println!("          ARNDTAI_BASE_URL); wybor przez --provider");
    println!("  transkrypty: FOLDER/.agent/sessions/");
}

fn serve_mcp(args: &[String]) -> i32 {
    let mut workspace = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-w" | "--workspace" => match args.get(i + 1) {
                Some(v) => {
                    workspace = PathBuf::from(v);
                    i += 2;
                }
                None => {
                    eprintln!("--workspace wymaga sciezki");
                    return 2;
                }
            },
            other => {
                eprintln!("nieznany argument mcp: {}", other);
                return 2;
            }
        }
    }
    mcp::serve(workspace)
}

/// Wskaznik ostatniej sesji w `.agent/resume` — jedyny sposob, by po restarcie
/// trafic w ten sam `session_id` (inaczej idzie nowy, a `steps` zostaje puste).
pub fn read_resume_pointer(workspace: &Path) -> Option<String> {
    let path = workspace.join(".agent").join("resume");
    let raw = std::fs::read_to_string(path).ok()?;
    let id = raw.trim();
    if id.is_empty() {
        None
    } else {
        Some(id.to_string())
    }
}

pub fn write_resume_pointer(workspace: &Path, session_id: &str) {
    let dir = workspace.join(".agent");
    if std::fs::create_dir_all(&dir).is_err() {
        return;
    }
    let _ = std::fs::write(dir.join("resume"), session_id);
}

fn run_task(args: &[String]) -> i32 {
    let mut workspace = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let mut provider: Option<String> = None;
    let mut max_steps: usize = 12;
    let mut quiet = false;
    let mut use_mcp = true;
    let mut resume = false;
    let mut memory = context::MemoryLevel::Lite;
    let mut task_parts: Vec<String> = Vec::new();

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-w" | "--workspace" => {
                if let Some(v) = args.get(i + 1) {
                    workspace = PathBuf::from(v);
                    i += 2;
                } else {
                    eprintln!("--workspace wymaga sciezki");
                    return 2;
                }
            }
            "--provider" => {
                if let Some(v) = args.get(i + 1) {
                    provider = Some(v.clone());
                    i += 2;
                } else {
                    eprintln!("--provider wymaga nazwy");
                    return 2;
                }
            }
            "--steps" => {
                if let Some(v) = args.get(i + 1) {
                    match v.parse::<usize>() {
                        Ok(n) if n > 0 => max_steps = n,
                        _ => {
                            eprintln!("--steps wymaga liczby > 0");
                            return 2;
                        }
                    }
                    i += 2;
                } else {
                    eprintln!("--steps wymaga liczby");
                    return 2;
                }
            }
            "--memory" => {
                if let Some(v) = args.get(i + 1) {
                    match context::MemoryLevel::parse(v) {
                        Some(level) => memory = level,
                        None => {
                            eprintln!("--memory: dozwolone lite, pro, ultra");
                            return 2;
                        }
                    }
                    i += 2;
                } else {
                    eprintln!("--memory wymaga poziomu (lite|pro|ultra)");
                    return 2;
                }
            }
            "--mcp" => {
                use_mcp = true;
                i += 1;
            }
            "--no-mcp" => {
                use_mcp = false;
                i += 1;
            }
            "--resume" => {
                resume = true;
                i += 1;
            }
            "-q" | "--quiet" => {
                quiet = true;
                i += 1;
            }
            other => {
                task_parts.push(other.to_string());
                i += 1;
            }
        }
    }

    let task = task_parts.join(" ");
    if task.trim().is_empty() {
        usage();
        return 2;
    }

    let cfg = agent::Config {
        workspace,
        max_steps,
        allowlist: tools::NAMES.iter().map(|n| n.to_string()).collect(),
        provider,
        quiet,
        mcp: use_mcp,
        memory,
        resume,
    };
    let report = agent::run(&task, &cfg);
    if report.status == "DONE" {
        0
    } else {
        1
    }
}

fn list_tools() {
    println!("Narzedzia perimeteru ({}):", tools::NAMES.len());
    for (name, example, desc) in tools::describe() {
        println!("  {:<12} {}", name, desc);
        println!("               args: {}", example);
    }
}

fn list_skills(level: context::MemoryLevel) {
    let ws = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let prefix = context::Prefix::load(&ws, level);
    println!("Folder:     {}", ws.display());
    println!("Osobowosc:  {}", prefix.persona_source);
    println!("Poziom pamieci: {}", prefix.memory_level.as_str());
    if prefix.skills.is_empty() {
        println!("Skille:     brak (szukam w {}/skills/<nazwa>/SKILL.md)", ws.display());
    } else {
        println!("Skille ({}):", prefix.skills.len());
        for skill in &prefix.skills {
            println!("  {:<16} {}", skill.name, skill.summary);
            println!("  {:<16} plik: {}", "", skill.path.display());
        }
    }
    println!(
        "Pamiec:     {}",
        prefix.memory_source.as_deref().unwrap_or("brak")
    );
}

fn status(level: context::MemoryLevel) {
    let ws = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let prefix = context::Prefix::load(&ws, level);
    println!("Folder:     {}", ws.display());
    println!("Osobowosc:  {} ({} znakow)", prefix.persona_source, prefix.persona.len());
    println!("Poziom pamieci: {}", prefix.memory_level.as_str());
    match &prefix.memory_source {
        Some(src) => println!("Pamiec:     {}", src),
        None => println!("Pamiec:     brak pliku pamieci"),
    }
    println!("Skille:     {}", prefix.skills.len());
    for skill in &prefix.skills {
        println!("  - {}", skill.name);
    }

    let files = context::sessions(&ws);
    println!("Sesje:      {}", files.len());
    if let Some(last) = files.last() {
        let name = last
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("?");
        println!("Ostatnia:   {}", name);
        if let Ok(text) = std::fs::read_to_string(last) {
            if let Some(line) = text.lines().last() {
                println!("  {}", first_chars(line, 200));
            }
        }
    }

    let brain = provider::Brain::from_env(None, "", &[]);
    println!("Mozg:       {}", brain.label());
    if let Some(note) = brain.note() {
        println!("Uwaga:      {}", note);
    }

    let outbox = ws.join(".agent").join("outbox").join("notifications.log");
    match std::fs::read_to_string(&outbox) {
        Ok(text) => println!("Outbox:     {} linii", text.lines().count()),
        Err(_) => println!("Outbox:     pusty"),
    }
}

fn first_chars(s: &str, n: usize) -> String {
    s.chars().take(n).collect()
}

fn read_text(path: &Path) -> String {
    std::fs::read_to_string(path).unwrap_or_default()
}

fn check(results: &mut Vec<(String, bool)>, name: impl Into<String>, ok: bool) {
    results.push((name.into(), ok));
}

fn demo() -> i32 {
    let base = std::env::current_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join(".agent")
        .join("demo");
    let _ = std::fs::remove_dir_all(&base);

    println!("== DEMO ArndtAi ==");
    let mut results: Vec<(String, bool)> = Vec::new();

    // --- 1. petla z narzedziami przez MCP ---
    let ws1 = base.join("run1");
    let _ = std::fs::create_dir_all(&ws1);
    let cfg1 = agent::Config {
        workspace: ws1.clone(),
        max_steps: 12,
        allowlist: tools::NAMES.iter().map(|n| n.to_string()).collect(),
        provider: Some("mock".to_string()),
        quiet: true,
        mcp: true,
        memory: context::MemoryLevel::Lite,
        resume: false,
    };
    let task1 = "write notatka.txt :: ArndtAi dziala; read notatka.txt; notify notatka gotowa";
    let r1 = agent::run(task1, &cfg1);
    let notatka = ws1.join("notatka.txt");
    let outbox1 = ws1.join(".agent").join("outbox").join("notifications.log");
    check(&mut results, "run1: plik zapisany", notatka.is_file());
    check(
        &mut results,
        "run1: tresc pliku",
        read_text(&notatka).contains("dziala"),
    );
    check(&mut results, "run1: 3 wywolania narzedzi", r1.tool_calls == 3);
    check(
        &mut results,
        "run1: powiadomienie w outboxie",
        read_text(&outbox1).contains("notatka gotowa"),
    );
    check(&mut results, "run1: status DONE", r1.status == "DONE");
    check(&mut results, "run1: kroki policzone", r1.steps >= 3);
    check(&mut results, "run1: powod wypelniony", !r1.reason.is_empty());
    check(&mut results, "run1: transkrypt sesji", r1.session.is_file());

    // --- 2. scope guard ---
    let ws2 = base.join("run2");
    let _ = std::fs::create_dir_all(&ws2);
    let cfg2 = agent::Config {
        workspace: ws2.clone(),
        max_steps: 4,
        allowlist: tools::NAMES.iter().map(|n| n.to_string()).collect(),
        provider: Some("mock".to_string()),
        quiet: true,
        mcp: true,
        memory: context::MemoryLevel::Lite,
        resume: false,
    };
    let r2 = agent::run("write ../escape.txt :: nie powinno powstac", &cfg2);
    check(&mut results, "run2: odmowa scope guardu", r2.denied >= 1);
    check(
        &mut results,
        "run2: plik poza workspace nie powstaje",
        !base.join("escape.txt").exists(),
    );
    check(&mut results, "run2: sesja konczy sie czysto", r2.status == "DONE");

    // --- 3. allowlista narzedzi ---
    let ws3 = base.join("run3");
    let _ = std::fs::create_dir_all(&ws3);
    let cfg3 = agent::Config {
        workspace: ws3.clone(),
        max_steps: 3,
        allowlist: vec!["fs.read".to_string()],
        provider: Some("mock".to_string()),
        quiet: true,
        mcp: false,
        memory: context::MemoryLevel::Lite,
        resume: false,
    };
    let r3 = agent::run("notify test allowlisty", &cfg3);
    let outbox3 = ws3.join(".agent").join("outbox").join("notifications.log");
    check(&mut results, "run3: odmowa allowlisty", r3.denied >= 1);
    check(
        &mut results,
        "run3: notify nie trafia do outboxa",
        !outbox3.exists(),
    );
    check(&mut results, "run3: sesja konczy sie czysto", r3.status == "DONE");

    // --- 4. MCP bezposrednio: handshake, tools/list, tools/call ---
    let ws4 = base.join("run4");
    let _ = std::fs::create_dir_all(&ws4);
    match mcp::McpClient::spawn(&ws4) {
        Ok(mut client) => {
            let listed = client.list_tools().unwrap_or_default();
            check(
                &mut results,
                "mcp: tools/list zwraca 3 narzedzia",
                listed.len() == tools::NAMES.len(),
            );
            // Kontrakt mcp.md: kazde wywolanie niesie wlasny `step_id`.
            let ctxw = tools::CallCtx {
                task_id: "demo".to_string(),
                session_id: "demo".to_string(),
                step_id: 1,
            };
            let wrote = client.call(
                "fs.write",
                &json!({"path": "mcp.txt", "content": "przez mcp"}),
                &ctxw,
            );
            check(
                &mut results,
                "mcp: fs.write zadzialal",
                matches!(&wrote, Ok(r) if r.ok),
            );
            check(
                &mut results,
                "mcp: plik z fs.write istnieje",
                read_text(&ws4.join("mcp.txt")) == "przez mcp",
            );
            let ctx_read = tools::CallCtx { step_id: 2, ..ctxw.clone() };
            let read = client.call("fs.read", &json!({"path": "mcp.txt"}), &ctx_read);
            check(
                &mut results,
                "mcp: fs.read zwraca tresc",
                matches!(
                    &read,
                    Ok(r) if r.ok
                        && r.output.get("content").and_then(|v| v.as_str()) == Some("przez mcp")
                ),
            );
            let ctx_notify = tools::CallCtx { step_id: 3, ..ctxw.clone() };
            let notified = client.call("notify.send", &json!({"message": "mcp ok"}), &ctx_notify);
            check(
                &mut results,
                "mcp: notify.send zwraca status queued",
                matches!(
                    &notified,
                    Ok(r) if r.ok
                        && r.output.get("status").and_then(|v| v.as_str()) == Some("queued")
                ),
            );
            client.shutdown();
        }
        Err(e) => {
            eprintln!("  mcp nie wystartowal: {}", e);
            check(&mut results, "mcp: serwer wystartowal", false);
        }
    }

    // --- 5. kontrakt narzedzi: kody bledow i zapis atomowy ---
    let ws5 = base.join("run5");
    let _ = std::fs::create_dir_all(&ws5);
    let code_of = |name: &str, args: serde_json::Value| -> Option<String> {
        tools::call(name, &args, &ws5).code
    };
    check(
        &mut results,
        "kontrakt: '..' daje DENIED",
        code_of("fs.read", json!({"path": "../tajne.txt"})).as_deref() == Some("DENIED"),
    );
    check(
        &mut results,
        "kontrakt: sciezka absolutna daje DENIED",
        code_of("fs.read", json!({"path": "/etc/passwd"})).as_deref() == Some("DENIED"),
    );
    check(
        &mut results,
        "kontrakt: pusta sciezka daje SCHEMA_ERROR",
        code_of("fs.read", json!({"path": ""})).as_deref() == Some("SCHEMA_ERROR"),
    );
    let big = "a".repeat(tools::MAX_WRITE_BYTES + 1);
    check(
        &mut results,
        "kontrakt: zapis ponad 1 MB daje DENIED",
        code_of("fs.write", json!({"path": "duzy.txt", "content": big})).as_deref()
            == Some("DENIED"),
    );
    check(
        &mut results,
        "kontrakt: plik ponad limit nie powstaje",
        !ws5.join("duzy.txt").exists(),
    );
    check(
        &mut results,
        "kontrakt: brak pliku daje NOT_FOUND",
        code_of("fs.read", json!({"path": "nie_ma.txt"})).as_deref() == Some("NOT_FOUND"),
    );
    check(
        &mut results,
        "kontrakt: fs.write bez content daje SCHEMA_ERROR",
        code_of("fs.write", json!({"path": "x.txt"})).as_deref() == Some("SCHEMA_ERROR"),
    );
    check(
        &mut results,
        "kontrakt: nieznane narzedzie daje DENIED",
        code_of("shell.exec", json!({"cmd": "ls"})).as_deref() == Some("DENIED"),
    );
    let atom = tools::call(
        "fs.write",
        &json!({"path": "atom.txt", "content": "atom"}),
        &ws5,
    );
    let leftovers: Vec<String> = std::fs::read_dir(&ws5)
        .map(|rd| {
            rd.filter_map(|e| e.ok())
                .filter_map(|e| e.file_name().into_string().ok())
                .filter(|n| n.ends_with(".tmp"))
                .collect()
        })
        .unwrap_or_default();
    check(
        &mut results,
        "kontrakt: zapis atomowy nie zostawia .tmp",
        atom.ok && leftovers.is_empty(),
    );
    let default_channel = tools::call(
        "notify.send",
        &json!({"message": "bez kanalu"}),
        &ws5,
    );
    check(
        &mut results,
        "kontrakt: notify bez kanalu uzywa 'default'",
        default_channel.ok
            && default_channel.output.get("channel").and_then(|v| v.as_str()) == Some("default"),
    );
    #[cfg(unix)]
    {
        use std::os::unix::fs::symlink;
        let link = ws5.join("link");
        let made = symlink("/etc", &link).is_ok();
        check(&mut results, "kontrakt: symlink utworzony", made);
        if made {
            check(
                &mut results,
                "kontrakt: symlink poza workspace daje DENIED",
                code_of("fs.read", json!({"path": "link/passwd"})).as_deref() == Some("DENIED"),
            );
        }
    }

    // --- 6. detektor dryfu ---
    let ws6 = base.join("run6");
    let _ = std::fs::create_dir_all(&ws6);
    let cfg6 = agent::Config {
        workspace: ws6.clone(),
        max_steps: 6,
        allowlist: tools::NAMES.iter().map(|n| n.to_string()).collect(),
        provider: Some("mock".to_string()),
        quiet: true,
        mcp: false,
        memory: context::MemoryLevel::Lite,
        resume: false,
    };
    let r6 = agent::run("read nie_ma.txt; read nie_ma.txt", &cfg6);
    check(&mut results, "dryf: powtorzenie wykryte", r6.drift == 1);
    check(
        &mut results,
        "dryf: drugie wywolanie nie poszlo",
        r6.tool_calls == 1,
    );

    // --- 7. poziomy pamieci i osobowosc z pliku ---
    let ws7 = base.join("run7");
    let _ = std::fs::create_dir_all(ws7.join("personality"));
    let _ = std::fs::create_dir_all(ws7.join("memory"));
    let _ = std::fs::write(ws7.join("personality").join("base.md"), "Jestem testerem.");
    let _ = std::fs::write(ws7.join("memory").join("project.md"), "Projekt testowy.");
    let _ = std::fs::write(ws7.join("memory").join("facts.md"), "Fakt: 1.");
    let lite = context::Prefix::load(&ws7, context::MemoryLevel::Lite);
    let pro = context::Prefix::load(&ws7, context::MemoryLevel::Pro);
    check(
        &mut results,
        "pamiec: osobowosc z personality/base.md",
        lite.persona_source == "personality/base.md",
    );
    check(
        &mut results,
        "pamiec: lite widzi osobowosc",
        lite.render().contains("Jestem testerem."),
    );
    check(
        &mut results,
        "pamiec: lite widzi project.md",
        lite.render().contains("Projekt testowy."),
    );
    check(
        &mut results,
        "pamiec: lite nie widzi facts.md",
        !lite.render().contains("Fakt: 1."),
    );
    check(
        &mut results,
        "pamiec: pro widzi facts.md",
        pro.render().contains("Fakt: 1."),
    );
    check(
        &mut results,
        "pamiec: nazwy poziomow",
        context::MemoryLevel::Lite.as_str() == "lite"
            && context::MemoryLevel::Ultra.as_str() == "ultra",
    );

    let passed = results.iter().filter(|(_, ok)| *ok).count();
    for (name, ok) in &results {
        println!("  {} {}", if *ok { "OK  " } else { "FAIL" }, name);
    }
    println!("{}/{} sprawdzen przeszlo", passed, results.len());
    if passed == results.len() {
        println!("DEMO OK");
        0
    } else {
        println!("DEMO FAIL");
        1
    }
}
