//! Magazyn SQLite: sessions / steps / outbox.
//! Plik: `.agent/state.db`. Jeden writer, transakcje rusqlite `bundled`.

use rusqlite::{params, Connection};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

fn now_ts() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

#[derive(Clone, Debug)]
pub struct StepRow {
    #[allow(dead_code)] // nosi tozsamosc kroku dla diagnostyki
    pub step_id: i64,
    pub tool: String,
    pub args_json: String,
    pub status: String,
    pub result_json: Option<String>,
}

#[derive(Clone)]
pub struct Store {
    pub path: PathBuf,
}

impl Store {
    pub fn new(db_path: &Path) -> Store {
        Store {
            path: db_path.to_path_buf(),
        }
    }

    pub fn for_workspace(workspace: &Path) -> Store {
        Store::new(&workspace.join(".agent").join("state.db"))
    }

    fn conn(&self) -> Result<Connection, String> {
        if let Some(parent) = self.path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("nie mozna utworzyc .agent: {}", e))?;
        }
        let c = Connection::open(&self.path).map_err(|e| format!("sqlite open: {}", e))?;
        // F6: WAL + busy_timeout. Jeden writer (rdzen), ale procesy MCP czytaja.
        c.busy_timeout(std::time::Duration::from_millis(5000))
            .map_err(|e| format!("sqlite busy_timeout: {}", e))?;
        c.pragma_update(None, "journal_mode", "WAL")
            .map_err(|e| format!("sqlite journal_mode: {}", e))?;
        c.pragma_update(None, "synchronous", "NORMAL")
            .map_err(|e| format!("sqlite synchronous: {}", e))?;
        Ok(c)
    }

    /// Diagnostyka: tryb dziennika wymuszony przez `conn`.
    pub fn journal_mode(&self) -> Result<String, String> {
        let c = self.conn()?;
        c.pragma_query_value(None, "journal_mode", |row| row.get::<_, String>(0))
            .map_err(|e| format!("sqlite journal_mode read: {}", e))
    }

    pub fn busy_timeout(&self) -> Result<i64, String> {
        let c = self.conn()?;
        c.pragma_query_value(None, "busy_timeout", |row| row.get::<_, i64>(0))
            .map_err(|e| format!("sqlite busy_timeout read: {}", e))
    }

    /// Tworzy tabele jesli nie istnieja. Idempotentne.
    pub fn init(&self) -> Result<(), String> {
        let c = self.conn()?;
        c.execute_batch(
            "CREATE TABLE IF NOT EXISTS sessions(
                 id TEXT PRIMARY KEY,
                 task TEXT NOT NULL,
                 created_at INTEGER NOT NULL
             );
             CREATE TABLE IF NOT EXISTS steps(
                 session_id TEXT NOT NULL,
                 step_id INTEGER NOT NULL,
                 tool TEXT NOT NULL,
                 args_json TEXT NOT NULL,
                 status TEXT NOT NULL,
                 result_json TEXT,
                 created_at INTEGER NOT NULL,
                 PRIMARY KEY(session_id, step_id)
             );
             CREATE TABLE IF NOT EXISTS outbox(
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 session_id TEXT NOT NULL,
                 step_id INTEGER NOT NULL,
                 payload TEXT NOT NULL,
                 created_at INTEGER NOT NULL
             );
             CREATE UNIQUE INDEX IF NOT EXISTS outbox_step_once
                 ON outbox(session_id, step_id);",
        )
        .map_err(|e| format!("sqlite schema: {}", e))?;
        Ok(())
    }

    pub fn create_session(&self, session_id: &str, task: &str) -> Result<(), String> {
        let c = self.conn()?;
        c.execute(
            "INSERT OR IGNORE INTO sessions(id, task, created_at) VALUES(?1, ?2, ?3)",
            params![session_id, task, now_ts()],
        )
        .map_err(|e| format!("sqlite session: {}", e))?;
        Ok(())
    }

    /// Przed wykonaniem toola: wiersz `proposed`. Jesli wiersz juz `done`, nie nadpisuje.
    pub fn proposed(
        &self,
        session_id: &str,
        step_id: u64,
        tool: &str,
        args_json: &str,
    ) -> Result<(), String> {
        let c = self.conn()?;
        c.execute(
            "INSERT OR IGNORE INTO steps(session_id, step_id, tool, args_json, status, created_at)
             VALUES(?1, ?2, ?3, ?4, 'proposed', ?5)",
            params![session_id, step_id as i64, tool, args_json, now_ts()],
        )
        .map_err(|e| format!("sqlite proposed: {}", e))?;
        Ok(())
    }

    /// Pelny wiersz kroku — do decyzji replay/skip/execute.
    pub fn fetch_step(&self, session_id: &str, step_id: u64) -> Result<Option<StepRow>, String> {
        let c = self.conn()?;
        let mut stmt = c
            .prepare(
                "SELECT step_id, tool, args_json, status, result_json FROM steps
                 WHERE session_id=?1 AND step_id=?2",
            )
            .map_err(|e| format!("sqlite fetch: {}", e))?;
        let mut rows = stmt
            .query(params![session_id, step_id as i64])
            .map_err(|e| format!("sqlite fetch: {}", e))?;
        match rows.next().map_err(|e| format!("sqlite fetch: {}", e))? {
            Some(row) => Ok(Some(StepRow {
                step_id: row.get(0).map_err(|e| format!("sqlite fetch: {}", e))?,
                tool: row.get(1).map_err(|e| format!("sqlite fetch: {}", e))?,
                args_json: row.get(2).map_err(|e| format!("sqlite fetch: {}", e))?,
                status: row.get(3).map_err(|e| format!("sqlite fetch: {}", e))?,
                result_json: row.get(4).map_err(|e| format!("sqlite fetch: {}", e))?,
            })),
            None => Ok(None),
        }
    }

    /// Wszystkie kroki sesji w kolejnosci `step_id`.
    #[allow(dead_code)] // API diagnostyczne (testy, przyszly `status`)
    pub fn steps_for_session(&self, session_id: &str) -> Result<Vec<StepRow>, String> {
        let c = self.conn()?;
        let mut stmt = c
            .prepare(
                "SELECT step_id, tool, args_json, status, result_json FROM steps
                 WHERE session_id=?1 ORDER BY step_id",
            )
            .map_err(|e| format!("sqlite steps: {}", e))?;
        let rows = stmt
            .query_map(params![session_id], |row| {
                Ok(StepRow {
                    step_id: row.get(0)?,
                    tool: row.get(1)?,
                    args_json: row.get(2)?,
                    status: row.get(3)?,
                    result_json: row.get(4)?,
                })
            })
            .map_err(|e| format!("sqlite steps: {}", e))?;
        let mut out = Vec::new();
        for r in rows {
            out.push(r.map_err(|e| format!("sqlite steps: {}", e))?);
        }
        Ok(out)
    }

    /// Krok, ktory byl `proposed` w chwili crashu, jest zamykany jako `abandoned`:
    /// at-most-once — efekt mogl juz czesciowo zajsc, wiec nie powtarzamy.
    pub fn mark_abandoned(
        &self,
        session_id: &str,
        step_id: u64,
        note_json: &str,
    ) -> Result<(), String> {
        let c = self.conn()?;
        let changed = c
            .execute(
                "UPDATE steps SET status='abandoned', result_json=?3
                 WHERE session_id=?1 AND step_id=?2 AND status='proposed'",
                params![session_id, step_id as i64, note_json],
            )
            .map_err(|e| format!("sqlite abandoned: {}", e))?;
        if changed == 0 {
            return Err(format!(
                "sqlite abandoned: krok {} nie byl w stanie proposed",
                step_id
            ));
        }
        Ok(())
    }

    /// Po wykonaniu: `done` + wynik. Zwykly update (bez outbox).
    pub fn complete(
        &self,
        session_id: &str,
        step_id: u64,
        result_json: &str,
    ) -> Result<(), String> {
        let c = self.conn()?;
        let changed = c
            .execute(
                "UPDATE steps SET status='done', result_json=?3 WHERE session_id=?1 AND step_id=?2",
                params![session_id, step_id as i64, result_json],
            )
            .map_err(|e| format!("sqlite complete: {}", e))?;
        if changed == 0 {
            return Err(format!(
                "sqlite complete: krok {} nie istnieje w tabeli steps",
                step_id
            ));
        }
        Ok(())
    }

    /// `notify.send`: zmiana statusu kroku + rekord w outbox w TEJ SAMEJ transakcji.
    pub fn complete_with_outbox(
        &self,
        session_id: &str,
        step_id: u64,
        result_json: &str,
        outbox_payload: &str,
    ) -> Result<(), String> {
        let mut c = self.conn()?;
        let tx = c
            .transaction()
            .map_err(|e| format!("sqlite tx: {}", e))?;
        let changed = tx
            .execute(
                "UPDATE steps SET status='done', result_json=?3 WHERE session_id=?1 AND step_id=?2",
                params![session_id, step_id as i64, result_json],
            )
            .map_err(|e| format!("sqlite complete: {}", e))?;
        if changed == 0 {
            return Err(format!(
                "sqlite complete: krok {} nie istnieje w tabeli steps",
                step_id
            ));
        }
        // Idempotentne: powtorka tej samej transakcji nie dubluje efektu.
        tx.execute(
            "INSERT OR IGNORE INTO outbox(session_id, step_id, payload, created_at)
             VALUES(?1, ?2, ?3, ?4)",
            params![session_id, step_id as i64, outbox_payload, now_ts()],
        )
        .map_err(|e| format!("sqlite outbox: {}", e))?;
        tx.commit().map_err(|e| format!("sqlite commit: {}", e))?;
        Ok(())
    }

    #[allow(dead_code)] // API diagnostyczne (testy)
    pub fn outbox_for_session(
        &self,
        session_id: &str,
    ) -> Result<Vec<String>, String> {        let c = self.conn()?;
        let mut stmt = c
            .prepare("SELECT payload FROM outbox WHERE session_id=?1 ORDER BY id")
            .map_err(|e| format!("sqlite outbox read: {}", e))?;
        let rows = stmt
            .query_map(params![session_id], |row| row.get::<_, String>(0))
            .map_err(|e| format!("sqlite outbox read: {}", e))?;
        let mut out = Vec::new();
        for r in rows {
            out.push(r.map_err(|e| format!("sqlite outbox read: {}", e))?);
        }
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_dir(tag: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "arndtai-store-{}-{}-{}",
            tag,
            std::process::id(),
            now_ts()
        ));
        let _ = std::fs::create_dir_all(&dir);
        dir
    }

    /// Faza B pkt 8 / F21: krok po restarcie jest czytany jako `done` z wynikiem,
    /// wiec petla moze pominac wykonanie (test konczy sie na decyzji, nie na liczniku).
    #[test]
    fn done_step_survives_restart_with_result() {
        let dir = test_dir("resume");
        let store = Store::new(&dir.join("state.db"));
        store.init().unwrap();
        store.create_session("s1", "zadanie").unwrap();
        store.proposed("s1", 1, "fs.write", "{\"path\":\"a.txt\"}").unwrap();
        store.complete("s1", 1, "{\"ok\":true}").unwrap();
        drop(store);

        let after_restart = Store::new(&dir.join("state.db"));
        after_restart.init().unwrap();
        let row = after_restart.fetch_step("s1", 1).unwrap().expect("krok 1");
        assert_eq!(row.status, "done");
        assert_eq!(row.tool, "fs.write");
        assert_eq!(row.result_json.as_deref(), Some("{\"ok\":true}"));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn wal_and_busy_timeout() {
        let dir = test_dir("wal");
        let store = Store::for_workspace(&dir);
        store.init().unwrap();
        assert_eq!(store.journal_mode().unwrap().to_lowercase(), "wal");
        assert_eq!(store.busy_timeout().unwrap(), 5000);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn outbox_is_once_per_step() {
        let dir = test_dir("outbox-once");
        let store = Store::for_workspace(&dir);
        store.init().unwrap();
        store.create_session("s1", "t").unwrap();
        store.proposed("s1", 1, "notify.send", "{\"message\":\"a\"}").unwrap();
        store
            .complete_with_outbox("s1", 1, "{\"ok\":true}", "{\"message\":\"a\"}")
            .unwrap();
        store
            .complete_with_outbox("s1", 1, "{\"ok\":true}", "{\"message\":\"a\"}")
            .unwrap();
        assert_eq!(store.outbox_for_session("s1").unwrap().len(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn complete_on_missing_step_is_an_error() {
        let dir = test_dir("complete-missing");
        let store = Store::for_workspace(&dir);
        store.init().unwrap();
        store.create_session("s1", "t").unwrap();
        assert!(store.complete("s1", 7, "{}").is_err());
        let _ = std::fs::remove_dir_all(&dir);
    }
}
