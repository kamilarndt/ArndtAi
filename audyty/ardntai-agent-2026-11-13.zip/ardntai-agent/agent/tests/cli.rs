//! Testy CLI z zewnatrz: uruchamiaja prawdziwa binarke i patrza na jej wyjscie.
//!
//! F23: `skills` i `status` mialy zaszyty poziom pamieci `lite`; teraz maja
//! respektowac `--memory <lite|pro|ultra>` tak samo jak `run`.

use std::path::{Path, PathBuf};
use std::process::Command;

struct Out {
    stdout: String,
    stderr: String,
    code: i32,
}

fn temp_dir(tag: &str) -> PathBuf {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir = std::env::temp_dir().join(format!(
        "arndtai-cli-{}-{}-{}",
        tag,
        std::process::id(),
        stamp
    ));
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

fn run(dir: &Path, args: &[&str]) -> Out {
    let out = Command::new(bin_path())
        .args(args)
        .current_dir(dir)
        .env_remove("ANTHROPIC_API_KEY")
        .env_remove("OPENAI_API_KEY")
        .output()
        .expect("binarka arndtai powinna sie uruchomic");
    Out {
        stdout: String::from_utf8_lossy(&out.stdout).to_string(),
        stderr: String::from_utf8_lossy(&out.stderr).to_string(),
        code: out.status.code().unwrap_or(-1),
    }
}

/// Sciezka do zbudowanej binarki. `CARGO_BIN_EXE_<nazwa>` bywa niedostepne
/// przy kompilacji testu, wiec bierzemy je w czasie wykonania, a potem
/// sasiada katalogu `deps/`.
fn bin_path() -> PathBuf {
    if let Ok(p) = std::env::var("CARGO_BIN_EXE_ardntai") {
        return PathBuf::from(p);
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent().and_then(|d| d.parent()) {
            let candidate = dir.join("ardntai");
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    PathBuf::from("target/debug/ardntai")
}

#[test]
fn status_with_memory_pro_prints_pro() {
    let dir = temp_dir("status-pro");
    std::fs::create_dir_all(dir.join("memory")).unwrap();
    std::fs::write(dir.join("memory").join("facts.md"), "Fakt: 42.").unwrap();

    let out = run(&dir, &["status", "--memory", "pro"]);
    assert_eq!(out.code, 0, "stderr: {}", out.stderr);
    assert!(
        out.stdout.contains("Poziom pamieci: pro"),
        "status --memory pro ma wypisac 'pro', bylo:\n{}",
        out.stdout
    );
    assert!(
        out.stdout.contains("memory/facts.md"),
        "poziom pro widzi facts.md, bylo:\n{}",
        out.stdout
    );

    // Kontrola: bez flagi nadal dziala poziom domyslny (lite), ktory nie czyta faktow.
    let default = run(&dir, &["status"]);
    assert_eq!(default.code, 0, "stderr: {}", default.stderr);
    assert!(
        default.stdout.contains("Poziom pamieci: lite"),
        "domyslnie ma byc lite, bylo:\n{}",
        default.stdout
    );
    assert!(
        !default.stdout.contains("memory/facts.md"),
        "lite nie czyta facts.md, bylo:\n{}",
        default.stdout
    );

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn status_accepts_memory_equals_form() {
    let dir = temp_dir("status-eq");
    let out = run(&dir, &["status", "--memory=ultra"]);
    assert_eq!(out.code, 0, "stderr: {}", out.stderr);
    assert!(
        out.stdout.contains("Poziom pamieci: ultra"),
        "bylo:\n{}",
        out.stdout
    );
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn skills_follow_the_memory_flag() {
    let dir = temp_dir("skills-pro");
    std::fs::create_dir_all(dir.join("memory")).unwrap();
    std::fs::write(dir.join("memory").join("facts.md"), "Fakt: 7.").unwrap();

    let lite = run(&dir, &["skills"]);
    assert_eq!(lite.code, 0, "stderr: {}", lite.stderr);
    assert!(
        lite.stdout.contains("Poziom pamieci: lite"),
        "bylo:\n{}",
        lite.stdout
    );

    let pro = run(&dir, &["skills", "--memory", "pro"]);
    assert_eq!(pro.code, 0, "stderr: {}", pro.stderr);
    assert!(
        pro.stdout.contains("Poziom pamieci: pro"),
        "skills --memory pro ma wypisac 'pro', bylo:\n{}",
        pro.stdout
    );
    assert!(
        pro.stdout.contains("memory/facts.md"),
        "poziom pro widzi facts.md, bylo:\n{}",
        pro.stdout
    );

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn unknown_memory_level_is_rejected() {
    let dir = temp_dir("status-bad");
    for cmd in ["status", "skills"] {
        let out = run(&dir, &[cmd, "--memory", "bogus"]);
        assert_eq!(out.code, 2, "{} ma zwrocic kod 2, stdout:\n{}", cmd, out.stdout);
        assert!(
            out.stderr.contains("lite, pro, ultra"),
            "{} ma powiedziec, jakie poziomy sa dozwolone, stderr:\n{}",
            cmd,
            out.stderr
        );
        assert!(
            !out.stdout.contains("Poziom pamieci:"),
            "{} nie moze wypisac stanu przy blednym argumencie, stdout:\n{}",
            cmd,
            out.stdout
        );
    }
    let _ = std::fs::remove_dir_all(&dir);
}
