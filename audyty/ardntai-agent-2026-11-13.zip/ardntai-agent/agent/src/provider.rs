//! Dwa mózgi agenta: offline (deterministyczny, do testów) i zdalny
//! (Anthropic lub OpenAI-compatible). HTTP idzie przez `curl`, żeby nie
//! dociągać ciężkich zależności.

use serde_json::{json, Value};
use std::env;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

#[derive(Clone)]
pub struct Turn {
    pub role: String,
    pub content: String,
}

pub enum Action {
    Tool { name: String, args: Value },
    Finish { summary: String },
}

pub struct Decision {
    pub thought: String,
    pub action: Action,
}

pub enum Brain {
    Mock(MockBrain),
    Remote(RemoteBrain),
}

#[derive(Clone, Copy)]
pub enum RemoteKind {
    Anthropic,
    OpenAi,
}

pub struct RemoteBrain {
    kind: RemoteKind,
    model: String,
    base_url: String,
    api_key: String,
    /// F9: prompt reklamuje tylko narzedzia przepuszczone przez allowliste.
    allowed: Vec<String>,
}

pub struct MockBrain {
    script: Vec<Action>,
    pos: usize,
    note: String,
}

impl Brain {
    pub fn from_env(provider: Option<&str>, task: &str, allowed: &[String]) -> Brain {
        let explicit = provider.map(|p| p.trim().to_lowercase());

        match explicit.as_deref() {
            Some("mock") | Some("offline") | Some("test") => {
                return Brain::Mock(MockBrain::new(task, String::new()))
            }
            _ => {}
        }

        let anthropic_key = env::var("ANTHROPIC_API_KEY").ok().filter(|s| !s.is_empty());
        let openai_key = env::var("OPENAI_API_KEY").ok().filter(|s| !s.is_empty());
        let generic_key = env::var("ARNDTAI_API_KEY").ok().filter(|s| !s.is_empty());

        let kind = match explicit.as_deref() {
            Some("anthropic") => Some(RemoteKind::Anthropic),
            Some("openai") | Some("http") => Some(RemoteKind::OpenAi),
            Some(other) => {
                return Brain::Mock(MockBrain::new(
                    task,
                    format!("nieznany provider '{}', uzywam trybu offline", other),
                ))
            }
            None => {
                if anthropic_key.is_some() || generic_key.is_some() {
                    Some(RemoteKind::Anthropic)
                } else if openai_key.is_some() {
                    Some(RemoteKind::OpenAi)
                } else {
                    None
                }
            }
        };

        let kind = match kind {
            Some(k) => k,
            None => {
                return Brain::Mock(MockBrain::new(
                    task,
                    "brak klucza API, uzywam trybu offline".to_string(),
                ))
            }
        };

        let (key, default_model, default_base, label) = match kind {
            RemoteKind::Anthropic => (
                anthropic_key.or(generic_key),
                "claude-sonnet-5-5".to_string(),
                "https://api.anthropic.com".to_string(),
                "anthropic",
            ),
            RemoteKind::OpenAi => (
                openai_key.or(generic_key),
                "gpt-4o".to_string(),
                "https://api.openai.com/v1".to_string(),
                "openai",
            ),
        };

        let api_key = match key {
            Some(k) => k,
            None => {
                return Brain::Mock(MockBrain::new(
                    task,
                    format!("wybrano '{}', ale brak klucza API", label),
                ))
            }
        };

        let model = env::var("ARNDTAI_MODEL").unwrap_or(default_model);
        let base_url = env::var("ARNDTAI_BASE_URL").unwrap_or(default_base);

        Brain::Remote(RemoteBrain {
            kind,
            model,
            base_url,
            api_key,
            allowed: allowed.to_vec(),
        })
    }

    pub fn next(
        &mut self,
        task: &str,
        prefix: &str,
        turns: &[Turn],
    ) -> Result<Decision, String> {
        match self {
            Brain::Mock(m) => Ok(m.next()),
            Brain::Remote(r) => r.next(task, prefix, turns),
        }
    }

    pub fn label(&self) -> String {
        match self {
            Brain::Mock(_) => "offline (mock)".to_string(),
            Brain::Remote(r) => {
                let kind = match r.kind {
                    RemoteKind::Anthropic => "anthropic",
                    RemoteKind::OpenAi => "openai",
                };
                format!("{} / {}", kind, r.model)
            }
        }
    }

    pub fn note(&self) -> Option<&str> {
        match self {
            Brain::Mock(m) => {
                if m.note.is_empty() {
                    None
                } else {
                    Some(m.note.as_str())
                }
            }
            Brain::Remote(_) => None,
        }
    }
}

impl MockBrain {
    pub fn new(task: &str, note: String) -> MockBrain {
        let mut script = Vec::new();
        for raw in task.split(|c| c == '\n' || c == ';') {
            let piece = raw.trim();
            if piece.is_empty() {
                continue;
            }
            let (verb, rest) = match piece.split_once(char::is_whitespace) {
                Some((v, r)) => (v.to_lowercase(), r.trim()),
                None => (piece.to_lowercase(), ""),
            };
            match verb.as_str() {
                "read" | "czytaj" => {
                    if !rest.is_empty() {
                        script.push(Action::Tool {
                            name: "fs.read".to_string(),
                            args: json!({ "path": rest }),
                        });
                    }
                }
                "write" | "zapisz" => {
                    if let Some((path, content)) = rest.split_once("::") {
                        script.push(Action::Tool {
                            name: "fs.write".to_string(),
                            args: json!({ "path": path.trim(), "content": content.trim() }),
                        });
                    }
                }
                "notify" | "powiadom" => {
                    if !rest.is_empty() {
                        script.push(Action::Tool {
                            name: "notify.send".to_string(),
                            args: json!({ "message": rest }),
                        });
                    }
                }
                _ => {}
            }
        }
        MockBrain {
            script,
            pos: 0,
            note,
        }
    }

    fn next(&mut self) -> Decision {
        if self.pos < self.script.len() {
            let idx = self.pos;
            self.pos += 1;
            let label = match &self.script[idx] {
                Action::Tool { name, .. } => name.clone(),
                Action::Finish { .. } => "finish".to_string(),
            };
            return Decision {
                thought: format!("krok {} z planu offline: {}", idx + 1, label),
                action: take_action(&mut self.script, idx),
            };
        }
        Decision {
            thought: "plan offline wykonany".to_string(),
            action: Action::Finish {
                summary: "Zadanie wykonane w trybie offline.".to_string(),
            },
        }
    }
}

fn take_action(script: &mut Vec<Action>, idx: usize) -> Action {
    // Wyciągamy akcję bez kopiowania enumów z wnętrza wektora.
    let placeholder = Action::Finish {
        summary: String::new(),
    };
    let action = std::mem::replace(&mut script[idx], placeholder);
    action
}

impl RemoteBrain {
    fn next(&mut self, task: &str, prefix: &str, turns: &[Turn]) -> Result<Decision, String> {
        let system = system_prompt(&self.allowed);
        let mut user = String::new();
        user.push_str(prefix);
        user.push_str("\n\n=== ZADANIE ===\n");
        user.push_str(task);
        user.push_str("\n\n=== HISTORIA ===\n");
        if turns.is_empty() {
            user.push_str("(pusto — to pierwszy krok)\n");
        } else {
            for t in turns.iter() {
                user.push_str(&format!("[{}] {}\n", t.role, t.content));
            }
        }
        user.push_str(
            "\nOdpowiedz WYLACZNIE jednym obiektem JSON: \
             {\"thought\":\"...\",\"tool\":\"fs.read|fs.write|notify.send\",\"args\":{...}} \
             albo {\"thought\":\"...\",\"finish\":\"podsumowanie\"}.",
        );

        let (body, headers) = match self.kind {
            RemoteKind::Anthropic => {
                let body = json!({
                    "model": self.model.clone(),
                    "max_tokens": 1200,
                    "system": system,
                    "messages": [{ "role": "user", "content": user }]
                });
                let headers = vec![
                    format!("x-api-key: {}", self.api_key),
                    "anthropic-version: 2023-06-01".to_string(),
                ];
                (body, headers)
            }
            RemoteKind::OpenAi => {
                let body = json!({
                    "model": self.model.clone(),
                    "max_tokens": 1200,
                    "messages": [
                        { "role": "system", "content": system },
                        { "role": "user", "content": user }
                    ]
                });
                let headers = vec![format!("authorization: Bearer {}", self.api_key)];
                (body, headers)
            }
        };

        let url = match self.kind {
            RemoteKind::Anthropic => format!("{}/v1/messages", self.base_url.trim_end_matches('/')),
            RemoteKind::OpenAi => format!(
                "{}/chat/completions",
                self.base_url.trim_end_matches('/')
            ),
        };

        let response = http_post(&url, &body.to_string(), &headers)?;

        let text = match self.kind {
            RemoteKind::Anthropic => response
                .pointer("/content/0/text")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string()),
            RemoteKind::OpenAi => response
                .pointer("/choices/0/message/content")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string()),
        };

        let text = text.ok_or_else(|| {
            let preview = truncate(&response.to_string(), 400);
            format!("odpowiedz modelu bez tresci: {}", preview)
        })?;

        parse_decision(&text)
    }
}

fn system_prompt(allowed: &[String]) -> String {
    let mut s = String::new();
    s.push_str("Jestes agentem wykonawczym. Kazdy krok to JEDNA akcja.\n");
    s.push_str("Dostepne narzedzia:\n");
    for (name, example, desc) in crate::tools::describe() {
        if !allowed.is_empty() && !allowed.iter().any(|a| a == name) {
            continue;
        }
        s.push_str(&format!("- {} — {}; argumenty: {}\n", name, desc, example));
    }
    s.push_str("Zasady:\n");
    s.push_str("1. Sciezki tylko wzgledne, bez '..' i bez '/'. Nic poza workspace'em.\n");
    s.push_str("2. Najpierw sprawdz, potem pisz. Nie powtarzaj nieudanej akcji bez zmiany.\n");
    s.push_str("3. Gdy zadanie jest zrobione, odpowiedz polami \"finish\".\n");
    s.push_str("4. Zero komentarza poza JSON-em.\n");
    s
}

/// F5: naglowki (w tym klucz API) nie ida w argv — argv jest widoczne w `ps`
/// i `/proc/<pid>/cmdline`. Trafiaja do pliku konfiguracji curl (0600), podawanego
/// jako `--config <sciezka>`; w argv zostaje tylko nazwa pliku.
fn curl_argv(url: &str, config_path: &str) -> Vec<String> {
    vec![
        "-sS".to_string(),
        "--max-time".to_string(),
        "120".to_string(),
        "--config".to_string(),
        config_path.to_string(),
        "-X".to_string(),
        "POST".to_string(),
        url.to_string(),
        "--data-binary".to_string(),
        "@-".to_string(),
    ]
}

fn curl_config_text(headers: &[String]) -> String {
    let mut out = String::new();
    let mut all = vec!["content-type: application/json".to_string()];
    all.extend(headers.iter().cloned());
    for header in all {
        let escaped = header.replace('\\', "\\\\").replace('"', "\\\"");
        out.push_str(&format!("header = \"{}\"\n", escaped));
    }
    out
}

fn write_private_config(dir: &Path, text: &str) -> Result<PathBuf, String> {
    use std::io::Write;
    let path = dir.join(format!(
        "curl-{}-{}.conf",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0)
    ));
    let mut opts = fs::OpenOptions::new();
    opts.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        opts.mode(0o600);
    }
    let mut file = opts
        .open(&path)
        .map_err(|e| format!("nie mozna utworzyc konfiguracji curl: {}", e))?;
    file.write_all(text.as_bytes())
        .map_err(|e| format!("nie mozna zapisac konfiguracji curl: {}", e))?;
    Ok(path)
}

fn http_post(url: &str, body: &str, headers: &[String]) -> Result<Value, String> {
    let dir = std::env::temp_dir();
    let config = write_private_config(&dir, &curl_config_text(headers))?;
    let argv = curl_argv(url, &config.to_string_lossy());

    let mut cmd = Command::new("curl");
    cmd.args(&argv)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let mut child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => {
            let _ = fs::remove_file(&config);
            return Err(format!("nie mozna uruchomic curl: {}", e));
        }
    };

    {
        let stdin = child
            .stdin
            .as_mut()
            .ok_or_else(|| "brak stdin dla curl".to_string())?;
        stdin
            .write_all(body.as_bytes())
            .map_err(|e| format!("nie mozna wyslac zapytania: {}", e))?;
    }

    let output = child
        .wait_with_output()
        .map_err(|e| format!("curl nie zakonczyl sie: {}", e))?;
    let _ = fs::remove_file(&config);

    if !output.status.success() {
        let err = String::from_utf8_lossy(&output.stderr);
        return Err(format!("curl blad: {}", truncate(err.trim(), 300)));
    }

    let text = String::from_utf8_lossy(&output.stdout).to_string();
    serde_json::from_str(&text).map_err(|e| format!("odpowiedz nie jest JSON-em: {}", e))
}

fn parse_decision(text: &str) -> Result<Decision, String> {
    let start = text.find('{').ok_or_else(|| "brak JSON-a w odpowiedzi".to_string())?;
    let end = text.rfind('}').ok_or_else(|| "brak konca JSON-a".to_string())?;
    if end < start {
        return Err("uszkodzony JSON w odpowiedzi".to_string());
    }
    let slice = &text[start..=end];
    let value: Value = serde_json::from_str(slice)
        .map_err(|e| format!("nie mozna sparsowac odpowiedzi: {}", e))?;

    let thought = value
        .get("thought")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();

    if let Some(summary) = value.get("finish").and_then(|v| v.as_str()) {
        return Ok(Decision {
            thought,
            action: Action::Finish {
                summary: summary.to_string(),
            },
        });
    }

    let name = value
        .get("tool")
        .and_then(|v| v.as_str())
        .ok_or_else(|| "odpowiedz bez 'tool' ani 'finish'".to_string())?
        .to_string();
    let args = value
        .get("args")
        .cloned()
        .unwrap_or_else(|| Value::Object(Default::default()));

    Ok(Decision {
        thought,
        action: Action::Tool { name, args },
    })
}

fn truncate(s: &str, n: usize) -> String {
    let clipped: String = s.chars().take(n).collect();
    if s.chars().count() > n {
        format!("{}...", clipped)
    } else {
        clipped
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const KEY: &str = "sk-test-SECRET-123";

    fn headers() -> Vec<String> {
        vec![
            format!("x-api-key: {}", KEY),
            "anthropic-version: 2023-06-01".to_string(),
        ]
    }

    #[test]
    fn prompt_lists_only_allowed_tools() {
        let prompt = system_prompt(&["fs.read".to_string()]);
        assert!(prompt.contains("fs.read"), "{}", prompt);
        assert!(
            !prompt.contains("fs.write") && !prompt.contains("notify.send"),
            "prompt nie moze reklamowac narzedzi spoza allowlisty: {}",
            prompt
        );
    }

    #[test]
    fn api_key_never_appears_in_curl_argv() {
        let argv = curl_argv("https://api.example/v1/messages", "/tmp/arndtai-curl.conf");
        let joined = argv.join(" ");
        assert!(
            !joined.contains(KEY),
            "klucz nie moze trafic do argv (widoczne w ps i /proc): {}",
            joined
        );
        assert!(!joined.contains("x-api-key"), "naglowki ida poza argv");
        assert!(joined.contains("--config"), "curl musi czytac naglowki z pliku");
        assert!(!joined.contains("-H"), "zadnego -H w argv");
    }

    #[test]
    fn headers_are_written_to_private_config() {
        let text = curl_config_text(&headers());
        assert!(text.contains(KEY), "klucz musi byc w pliku konfiguracji");
        assert!(text.contains("x-api-key"));
        assert!(text.contains("content-type: application/json"));
    }

    #[test]
    fn config_file_is_owner_only_and_removed() {
        let dir = std::env::temp_dir().join(format!(
            "arndtai-curl-{}-{}",
            std::process::id(),
            crate::read_resume_pointer(std::path::Path::new("/nonexistent")).is_none() as u8
        ));
        let _ = std::fs::create_dir_all(&dir);
        let path = write_private_config(&dir, &curl_config_text(&headers())).unwrap();
        use std::os::unix::fs::PermissionsExt;
        let mode = std::fs::metadata(&path).unwrap().permissions().mode() & 0o777;
        assert_eq!(mode, 0o600, "plik z kluczem musi byc tylko dla wlasciciela");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
